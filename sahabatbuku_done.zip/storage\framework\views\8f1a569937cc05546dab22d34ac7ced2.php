<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($simulasi->judul_simulasi); ?> - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 min-h-screen px-8 py-8 overflow-y-auto">


        
        <h1 class="mb-8 text-4xl font-bold text-black font-jakarta"><?php echo e($simulasi->judul_simulasi); ?></h1>

        <div class="max-w-2xl">
            
            <div class="p-6 mb-8 bg-white rounded-[12px] shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)]">
                <div class="grid grid-cols-2 gap-6 sm:grid-cols-4">
                    
                    <div>
                        <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Buku</p>
                        <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($simulasi->buku->judul_buku ?? 'Tidak tersedia'); ?></p>
                    </div>

                    
                    <div>
                        <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Durasi</p>
                        <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($simulasi->durasi_menit); ?> menit</p>
                    </div>

                    
                    <div>
                        <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Jumlah Soal</p>
                        <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($simulasi->jumlah_soal); ?> soal</p>
                    </div>

                    
                    <div>
                        <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Passing Grade</p>
                        <p class="text-sm font-bold text-gray-800 font-jakarta">70%</p>
                    </div>
                </div>
            </div>

            
            <?php if($hasilTerakhir): ?>
            <div class="p-6 mb-8 bg-white rounded-[12px] shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)]">
                <h2 class="mb-4 text-lg font-bold text-gray-800 font-jakarta">Hasil Terakhir</h2>
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div>
                        <p class="mb-1 text-xs font-semibold text-gray-600 font-jakarta">Skor</p>
                        <p class="text-2xl font-bold text-[#F0924E] font-jakarta"><?php echo e($hasilTerakhir->skor); ?>%</p>
                    </div>
                    <div>
                        <p class="mb-1 text-xs font-semibold text-gray-600 font-jakarta">Status</p>
                        <?php if($hasilTerakhir->skor >= 70): ?>
                            <span class="inline-block px-3 py-1 text-sm font-bold text-white bg-green-500 rounded-full font-jakarta">
                                Lulus
                            </span>
                        <?php else: ?>
                            <span class="inline-block px-3 py-1 text-sm font-bold text-white bg-red-500 rounded-full font-jakarta">
                                Tidak Lulus
                            </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <p class="mb-1 text-xs font-semibold text-gray-600 font-jakarta">Tanggal</p>
                        <p class="text-sm text-gray-800 font-jakarta"><?php echo e($hasilTerakhir->created_at->format('d M Y H:i')); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            
            <?php if($cooldown): ?>
            <div class="p-6 mb-6 border-l-4 border-orange-400 bg-orange-50 rounded-[12px]">
                <p class="text-sm font-semibold text-orange-800 font-jakarta">
                    Kamu sudah mengerjakan hari ini. Silakan coba lagi besok.
                </p>
            </div>
            <button disabled 
                    class="w-full py-3 text-lg font-bold text-gray-400 bg-gray-300 rounded-[12px] cursor-not-allowed font-jakarta">
                Mulai Ujian
            </button>
            <?php else: ?>
            <form action="<?php echo e(route('user.simulasi.start', $simulasi->id_simulasi)); ?>" method="POST" class="inline-block w-full">
                <?php echo csrf_field(); ?>
                <button type="submit" 
                        class="w-full py-3 text-lg font-bold text-white bg-[#F0924E] rounded-[12px] hover:bg-opacity-90 transition font-jakarta">
                    Mulai Ujian
                </button>
            </form>
            <?php endif; ?>
        </div>

    </main>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/user/simulasi/show.blade.php ENDPATH**/ ?>