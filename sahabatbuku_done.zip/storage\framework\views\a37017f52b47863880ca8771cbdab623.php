<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Simulasi - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-[#F5F5F5]">
<div class="flex flex-col min-h-screen lg:flex-row">
    <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
    <main class="flex-1 p-4 sm:p-6 lg:p-16">
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10">
            Edit Simulasi
        </h1>

        <div class="max-w-2xl mx-auto bg-white shadow-md rounded-2xl p-6 sm:p-8">
            <form action="<?php echo e(route('simulasi.update', $simulasi->id_simulasi)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Judul Simulasi -->
                <div>
                    <label for="judul_simulasi" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Judul Simulasi
                    </label>
                    <input type="text" 
                           id="judul_simulasi" 
                           name="judul_simulasi" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                           placeholder="Masukkan judul simulasi"
                           value="<?php echo e(old('judul_simulasi', $simulasi->judul_simulasi)); ?>"
                           required>
                    <?php $__errorArgs = ['judul_simulasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Buku -->
                <div>
                    <label for="id_buku" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Buku
                    </label>
                    <select id="id_buku" 
                            name="id_buku" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                            required>
                        <option value="">-- Pilih Buku --</option>
                        <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id_buku); ?>" <?php echo e(old('id_buku', $simulasi->id_buku) == $b->id_buku ? 'selected' : ''); ?>>
                                <?php echo e($b->judul_buku); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_buku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Durasi Menit -->
                <div>
                    <label for="durasi_menit" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Durasi (menit)
                    </label>
                    <input type="number" 
                           id="durasi_menit" 
                           name="durasi_menit" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                           placeholder="Masukkan durasi dalam menit"
                           value="<?php echo e(old('durasi_menit', $simulasi->durasi_menit)); ?>"
                           min="1"
                           max="180"
                           required>
                    <?php $__errorArgs = ['durasi_menit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Jumlah Soal -->
                <div>
                    <label for="jumlah_soal" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Jumlah Soal
                    </label>
                    <input type="number" 
                           id="jumlah_soal" 
                           name="jumlah_soal" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                           placeholder="Masukkan jumlah soal"
                           value="<?php echo e(old('jumlah_soal', $simulasi->jumlah_soal)); ?>"
                           min="5"
                           max="100"
                           required>
                    <?php $__errorArgs = ['jumlah_soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status -->
                <div>
                    <label for="status" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Status
                    </label>
                    <select id="status" 
                            name="status" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                            required>
                        <option value="aktif" <?php echo e(old('status', $simulasi->status) === 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="nonaktif" <?php echo e(old('status', $simulasi->status) === 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tombol -->
                <div class="flex flex-col gap-3 pt-6 sm:flex-row sm:justify-between">
                    <a href="<?php echo e(route('simulasi.index')); ?>" 
                       class="flex justify-center items-center px-6 py-3 text-lg font-bold text-gray-700 bg-gray-300 rounded-lg hover:bg-opacity-90 transition font-jakarta">
                        Batal
                    </a>
                    <button type="submit" 
                            class="flex justify-center items-center px-6 py-3 text-lg font-bold text-black bg-admin-orange rounded-lg hover:bg-opacity-90 transition font-jakarta">
                        Update
                    </button>
                </div>
            </form>
        </div>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/admin/simulasi/edit.blade.php ENDPATH**/ ?>