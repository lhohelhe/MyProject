<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulasi Ujian - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 px-8 py-8 overflow-y-auto">

        
        <h1 class="mb-6 text-2xl font-bold text-black font-jakarta">Simulasi Ujian</h1>

        
        <?php if($simulasi->isEmpty()): ?>
            <p class="italic text-gray-400 font-jakarta">belum ada simulasi tersedia.</p>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                <?php $__currentLoopData = $simulasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col bg-white rounded-[12px] shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] overflow-hidden hover:shadow-[0px_6px_16px_0px_rgba(0,0,0,0.2)] transition-shadow">

                    
                    <div class="relative px-4 py-4 bg-gradient-to-r from-blue-50 to-blue-100 border-b border-blue-200">
                        <div class="flex items-start justify-between gap-2 mb-2">
                            <h3 class="flex-1 text-sm font-bold text-gray-800 line-clamp-2 font-jakarta">
                                <?php echo e($sim->judul_simulasi); ?>

                            </h3>
                            <?php if(in_array($sim->id_simulasi, $cooldowns)): ?>
                                <span class="px-2 py-1 text-xs font-semibold text-gray-600 bg-gray-300 rounded-full whitespace-nowrap">
                                    Cooldown
                                </span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-semibold text-white bg-[#F0924E] rounded-full whitespace-nowrap">
                                    Aktif
                                </span>
                            <?php endif; ?>
                        </div>
                        <p class="text-xs text-gray-600 font-jakarta">
                            <?php echo e($sim->buku->judul_buku ?? 'Buku tidak tersedia'); ?>

                        </p>
                    </div>

                    
                    <div class="flex-1 px-4 py-4 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-gray-600 font-jakarta">Durasi</span>
                            <span class="text-sm font-semibold text-gray-800 font-jakarta"><?php echo e($sim->durasi_menit); ?> mnt</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-gray-600 font-jakarta">Soal</span>
                            <span class="text-sm font-semibold text-gray-800 font-jakarta"><?php echo e($sim->jumlah_soal); ?> soal</span>
                        </div>
                        
                        <?php if(in_array($sim->id_simulasi, $cooldowns)): ?>
                        <div class="p-2 text-center bg-gray-100 rounded">
                            <p class="text-xs text-gray-600 font-jakarta">Cooldown • Besok</p>
                        </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="px-4 py-3 border-t border-gray-200">
                        <?php if(in_array($sim->id_simulasi, $cooldowns)): ?>
                            <button disabled 
                                    class="w-full py-2 text-sm font-bold text-gray-400 bg-gray-200 rounded-[8px] cursor-not-allowed font-jakarta">
                                Mulai
                            </button>
                        <?php else: ?>
                            <a href="<?php echo e(route('user.simulasi.show', $sim->id_simulasi)); ?>" 
                               class="block w-full py-2 text-sm font-bold text-center text-white bg-[#F0924E] rounded-[8px] hover:bg-opacity-90 transition font-jakarta">
                                Mulai
                            </a>
                        <?php endif; ?>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </main>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/user/simulasi/index.blade.php ENDPATH**/ ?>