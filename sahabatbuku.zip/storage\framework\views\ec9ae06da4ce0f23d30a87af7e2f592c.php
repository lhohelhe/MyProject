<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($quiz->judul_quiz); ?> - Quiz - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>* { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex flex-col min-h-screen">

    
    <div class="flex items-center justify-between p-6 bg-white border-b border-gray-200 shadow-sm">
        <div class="flex items-center gap-4">
            <h1 class="text-2xl font-bold text-gray-800 font-jakarta"><?php echo e($quiz->judul_quiz); ?></h1>
            <?php
                $difficultyLabel = [
                    'easy' => 'Mudah',
                    'medium' => 'Sedang',
                    'hard' => 'Sulit'
                ][$difficulty] ?? 'Mudah';
                $difficultyColor = [
                    'easy' => 'bg-green-500',
                    'medium' => 'bg-yellow-500',
                    'hard' => 'bg-red-500'
                ][$difficulty] ?? 'bg-green-500';
            ?>
            <span class="px-3 py-1 text-sm font-bold text-white rounded-full <?php echo e($difficultyColor); ?> font-jakarta">
                <?php echo e($difficultyLabel); ?>

            </span>
        </div>
        
        
        <div class="font-mono text-3xl font-bold" id="timer" style="color: #333;">
            10:00
        </div>
    </div>

    
    <main class="flex-1 flex flex-col items-center justify-center p-6 overflow-y-auto sm:p-8">
        <div class="w-full max-w-2xl">
            <form id="quizForm" action="<?php echo e(route('user.quiz.submit')); ?>" method="POST" class="space-y-8">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_quiz" value="<?php echo e($quiz->id_quiz); ?>">

                
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-semibold text-gray-600 font-jakarta" id="progressText">
                            Soal 1 dari <?php echo e($soal->count()); ?>

                        </span>
                        <span class="text-sm font-semibold text-gray-600 font-jakarta" id="progressPercent">
                            10%
                        </span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div id="progressBar" class="bg-[#F4922A] h-2 rounded-full transition-all duration-300" style="width: 10%;"></div>
                    </div>
                </div>

                
                <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="question-<?php echo e($index); ?>" class="question-container hidden">
                    
                    <div class="mb-8 p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
                        <p class="text-2xl font-bold text-gray-800 font-jakarta"><?php echo e($s->pertanyaan); ?></p>
                    </div>

                    
                    <div class="space-y-3 mb-8">
                        <?php $__currentLoopData = ['a', 'b', 'c', 'd', 'e']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $columnName = 'opsi_' . $option;
                            $optionValue = $s->$columnName;
                        ?>
                        <?php if(!empty($optionValue)): ?>
                        <button type="button" 
                                class="answer-btn w-full p-4 text-left bg-white border-2 border-gray-200 rounded-xl transition-all hover:border-[#F4922A] hover:bg-orange-50 font-jakarta"
                                onclick="selectAnswer('<?php echo e($s->id_soal_quiz); ?>', '<?php echo e($option); ?>', this, <?php echo e($index); ?>)"
                                data-soal="<?php echo e($s->id_soal_quiz); ?>"
                                data-option="<?php echo e($option); ?>"
                                data-question="<?php echo e($index); ?>">
                            <div class="flex items-start gap-3">
                                <span class="flex-shrink-0 w-8 h-8 flex items-center justify-center font-bold text-gray-700 bg-gray-100 rounded-full">
                                    <?php echo e(strtoupper($option)); ?>

                                </span>
                                <span class="flex-1 text-gray-700">
                                    <?php echo e($optionValue); ?>

                                </span>
                            </div>
                        </button>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <div class="flex flex-col gap-4 items-center pt-4">
                    <div class="flex justify-between items-center w-full gap-4">
                        <button type="button" 
                                id="prevBtn"
                                onclick="prevQuestion()"
                                class="flex-1 py-3 text-lg font-bold text-slate-700 bg-white border-2 border-slate-200 rounded-xl hover:bg-slate-50 transition font-jakarta">
                            &larr; Sebelumnya
                        </button>
                        <button type="button" 
                                id="nextBtn"
                                onclick="nextQuestion()"
                                class="flex-1 py-3 text-lg font-bold text-white bg-green-600 hover:bg-green-700 transition font-jakarta">
                            Selanjutnya &rarr;
                        </button>
                        <button type="button" 
                                id="submitBtn"
                                onclick="showConfirmModal()"
                                class="flex-1 py-3 text-lg font-bold text-white bg-[#F4922A] hover:bg-opacity-95 transition font-jakarta hidden">
                            Submit Quiz
                        </button>
                    </div>

                    
                    <div id="questionIndicator" class="text-sm font-semibold text-slate-500 font-jakarta mt-2">
                        1 / 10
                    </div>
                </div>
            </form>
        </div>
    </main>
</div>


<div id="confirmModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl p-6 max-w-sm shadow-xl border border-slate-100">
        <h2 class="mb-4 text-xl font-bold text-gray-800 font-jakarta">Konfirmasi Submit</h2>
        <p class="mb-6 text-gray-700 font-jakarta">Apakah Anda yakin ingin mengirimkan jawaban? Anda tidak dapat mengubahnya lagi.</p>
        <div class="flex gap-4">
            <button type="button" 
                    onclick="closeConfirmModal()"
                    class="flex-1 py-2 text-lg font-bold text-gray-700 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition font-jakarta">
                Batal
            </button>
            <button type="button" 
                    onclick="submitQuiz()"
                    class="flex-1 py-2 text-lg font-bold text-white bg-green-600 rounded-xl hover:bg-green-700 transition font-jakarta">
                Submit
            </button>
        </div>
    </div>
</div>

<script>
let currentQuestion = 0;
const totalQuestions = <?php echo e($soal->count()); ?>;
const timerDuration = 10 * 60; // 10 minutes in seconds
const selectedAnswers = {};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    showQuestion(0);
    startTimer();
});

// Timer
function startTimer() {
    let secondsRemaining = timerDuration;
    
    const timerInterval = setInterval(() => {
        const minutes = Math.floor(secondsRemaining / 60);
        const seconds = secondsRemaining % 60;
        
        const timerEl = document.getElementById('timer');
        timerEl.textContent = String(minutes).padStart(2, '0') + ':' + 
                              String(seconds).padStart(2, '0');
        
        // Warna merah jika < 1 menit
        if (secondsRemaining < 60) {
            timerEl.style.color = '#DC2626';
        }
        
        if (secondsRemaining <= 0) {
            clearInterval(timerInterval);
            autoSubmitQuiz();
        }
        
        secondsRemaining--;
    }, 1000);
}

// Show question
function showQuestion(index) {
    currentQuestion = index;
    document.querySelectorAll('.question-container').forEach(el => el.classList.add('hidden'));
    document.getElementById('question-' + index).classList.remove('hidden');
    
    // Update progress
    const progress = Math.round((index + 1) / totalQuestions * 100);
    document.getElementById('progressBar').style.width = progress + '%';
    document.getElementById('progressText').textContent = 'Soal ' + (index + 1) + ' dari ' + totalQuestions;
    document.getElementById('progressPercent').textContent = progress + '%';
    
    // Update button visibilities
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    const questionIndicator = document.getElementById('questionIndicator');
    
    if (index === 0) {
        prevBtn.classList.add('invisible');
    } else {
        prevBtn.classList.remove('invisible');
    }
    
    if (index === totalQuestions - 1) {
        nextBtn.classList.add('hidden');
        submitBtn.classList.remove('hidden');
    } else {
        nextBtn.classList.remove('hidden');
        submitBtn.classList.add('hidden');
    }
    
    if (questionIndicator) {
        questionIndicator.textContent = (index + 1) + ' / ' + totalQuestions;
    }
    
    // Restore selected answer
    document.querySelectorAll(`[data-question="${index}"]`).forEach(btn => {
        btn.classList.remove('border-[#F4922A]', 'bg-orange-100', 'border-2');
        btn.classList.add('border-gray-200', 'bg-white');
    });
    
    for (let soalId in selectedAnswers) {
        const answeredOption = selectedAnswers[soalId];
        const answeredBtn = document.querySelector(`[data-question="${index}"][data-option="${answeredOption}"]`);
        if (answeredBtn) {
            answeredBtn.classList.remove('border-gray-200', 'bg-white');
            answeredBtn.classList.add('border-[#F4922A]', 'bg-orange-100', 'border-2');
        }
    }
}

// Navigation functions
function prevQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        showQuestion(currentQuestion);
    }
}

function nextQuestion() {
    if (currentQuestion < totalQuestions - 1) {
        currentQuestion++;
        showQuestion(currentQuestion);
    }
}

// Select answer
function selectAnswer(soalId, option, button, questionIndex) {
    selectedAnswers[soalId] = option;
    
    // Remove highlight from other buttons for this question
    document.querySelectorAll(`[data-question="${questionIndex}"]`).forEach(btn => {
        btn.classList.remove('border-[#F4922A]', 'bg-orange-100', 'border-2');
        btn.classList.add('border-gray-200', 'bg-white');
    });
    
    // Highlight selected button
    button.classList.remove('border-gray-200', 'bg-white');
    button.classList.add('border-[#F4922A]', 'bg-orange-100', 'border-2');
}

// Submit
function showConfirmModal() {
    document.getElementById('confirmModal').classList.remove('hidden');
}

function closeConfirmModal() {
    document.getElementById('confirmModal').classList.add('hidden');
}

function submitQuiz() {
    closeConfirmModal();
    
    // Add hidden inputs for answers
    const form = document.getElementById('quizForm');
    for (let soalId in selectedAnswers) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'jawaban[' + soalId + ']';
        input.value = selectedAnswers[soalId];
        form.appendChild(input);
    }
    
    form.submit();
}

function autoSubmitQuiz() {
    alert('Waktu quiz telah habis. Quiz akan dikirimkan secara otomatis.');
    submitQuiz();
}

// Close modal on escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeConfirmModal();
    }
});

if (typeof lucide !== 'undefined') lucide.createIcons();
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/user/quiz/exam.blade.php ENDPATH**/ ?>