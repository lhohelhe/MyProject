<?php $__env->startSection('title', 'Kelola Soal Quiz - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10 text-slate-800">
            Kelola Soal — <?php echo e($quiz->judul_quiz); ?>

        </h1>

        <!-- Info Quiz / Summary -->
        <div class="p-4 mb-6 bg-white shadow-md rounded-xl lg:p-4">
            <p class="text-lg font-semibold text-gray-700 font-jakarta">
                Total Soal: <span class="ml-2 font-bold text-slate-800"><?php echo e($soal->total()); ?></span>
            </p>
        </div>

        <!-- Flash Message -->
        <?php if(session('success')): ?>
        <div class="px-4 py-3 mb-6 text-green-800 bg-green-100 rounded-xl font-jakarta">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <!-- Form Tambah Soal -->
        <div class="p-6 mb-8 bg-white shadow-md rounded-2xl sm:p-8 border border-slate-100">
            <h2 class="mb-6 text-2xl font-bold text-slate-800 font-jakarta">Tambah Soal Baru</h2>
            
            <form action="<?php echo e(route('admin.quiz.storeSoal', $quiz->id_quiz)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Pertanyaan -->
                <div>
                    <label for="pertanyaan" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                        Pertanyaan
                    </label>
                    <textarea id="pertanyaan" 
                              name="pertanyaan" 
                              class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pertanyaan soal"
                              rows="4"
                              required><?php echo e(old('pertanyaan')); ?></textarea>
                    <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Grid Pilihan Jawaban -->
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <!-- Pilihan A -->
                    <div>
                        <label for="pilihan_a" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Pilihan A
                        </label>
                        <input type="text" 
                               id="pilihan_a" 
                               name="pilihan_a" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan pilihan A"
                               value="<?php echo e(old('pilihan_a')); ?>"
                               required>
                        <?php $__errorArgs = ['pilihan_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Pilihan B -->
                    <div>
                        <label for="pilihan_b" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Pilihan B
                        </label>
                        <input type="text" 
                               id="pilihan_b" 
                               name="pilihan_b" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan pilihan B"
                               value="<?php echo e(old('pilihan_b')); ?>"
                               required>
                        <?php $__errorArgs = ['pilihan_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Pilihan C -->
                    <div>
                        <label for="pilihan_c" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Pilihan C
                        </label>
                        <input type="text" 
                               id="pilihan_c" 
                               name="pilihan_c" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan pilihan C"
                               value="<?php echo e(old('pilihan_c')); ?>"
                               required>
                        <?php $__errorArgs = ['pilihan_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Pilihan D -->
                    <div>
                        <label for="pilihan_d" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Pilihan D
                        </label>
                        <input type="text" 
                               id="pilihan_d" 
                               name="pilihan_d" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan pilihan D"
                               value="<?php echo e(old('pilihan_d')); ?>"
                               required>
                        <?php $__errorArgs = ['pilihan_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Pilihan E -->
                    <div class="md:col-span-2">
                        <label for="pilihan_e" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Pilihan E
                        </label>
                        <input type="text" 
                               id="pilihan_e" 
                               name="pilihan_e" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan pilihan E"
                               value="<?php echo e(old('pilihan_e')); ?>"
                               required>
                        <?php $__errorArgs = ['pilihan_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Grid Kunci Jawaban & Difficulty -->
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <!-- Kunci Jawaban -->
                    <div>
                        <label for="kunci_jawaban" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Kunci Jawaban
                        </label>
                        <select id="kunci_jawaban" 
                                name="kunci_jawaban" 
                                class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                                required>
                            <option value="">-- Pilih Jawaban Benar --</option>
                            <option value="a" <?php echo e(old('kunci_jawaban') === 'a' ? 'selected' : ''); ?>>A</option>
                            <option value="b" <?php echo e(old('kunci_jawaban') === 'b' ? 'selected' : ''); ?>>B</option>
                            <option value="c" <?php echo e(old('kunci_jawaban') === 'c' ? 'selected' : ''); ?>>C</option>
                            <option value="d" <?php echo e(old('kunci_jawaban') === 'd' ? 'selected' : ''); ?>>D</option>
                            <option value="e" <?php echo e(old('kunci_jawaban') === 'e' ? 'selected' : ''); ?>>E</option>
                        </select>
                        <?php $__errorArgs = ['kunci_jawaban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Tingkat Kesulitan -->
                    <div>
                        <label for="difficulty" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                            Tingkat Kesulitan
                        </label>
                        <select id="difficulty" 
                                name="difficulty" 
                                class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                                required>
                            <option value="easy" <?php echo e(old('difficulty') === 'easy' ? 'selected' : ''); ?>>Easy (Mudah)</option>
                            <option value="medium" <?php echo e(old('difficulty') === 'medium' ? 'selected' : ''); ?>>Medium (Sedang)</option>
                            <option value="hard" <?php echo e(old('difficulty') === 'hard' ? 'selected' : ''); ?>>Hard (Sulit)</option>
                        </select>
                        <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Pembahasan -->
                <div>
                    <label for="pembahasan" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                        Pembahasan <span class="text-slate-400 font-normal">(Opsional)</span>
                    </label>
                    <textarea id="pembahasan" 
                              name="pembahasan" 
                              class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pembahasan soal"
                              rows="3"><?php echo e(old('pembahasan')); ?></textarea>
                    <?php $__errorArgs = ['pembahasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit Button -->
                <div class="flex justify-end pt-3">
                    <button type="submit" 
                            class="px-6 py-3 text-lg font-bold text-white bg-admin-orange rounded-xl hover:bg-opacity-90 transition font-jakarta">
                        Tambah Soal
                    </button>
                </div>
            </form>
        </div>

        <!-- Daftar Soal -->
        <div class="overflow-hidden bg-white shadow-md rounded-2xl border border-slate-100">
            <div class="p-6">
                <h2 class="mb-6 text-2xl font-bold text-slate-800 font-jakarta">Daftar Soal</h2>

                <!-- Header Tabel Desktop -->
                <div class="hidden p-4 mb-4 rounded-lg bg-slate-50 lg:block border border-slate-100">
                    <div class="grid grid-cols-12 gap-4 text-base font-semibold text-center font-jakarta text-slate-600">
                        <div class="col-span-1">No</div>
                        <div class="col-span-6 text-left">Pertanyaan</div>
                        <div class="col-span-2">Kesulitan</div>
                        <div class="col-span-1">Kunci</div>
                        <div class="col-span-2">Aksi</div>
                    </div>
                </div>

                <!-- List Soal -->
                <?php $__empty_1 = true; $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-4 mb-4 border border-slate-100 rounded-xl bg-white hover:shadow-sm transition-shadow">
                    
                    <!-- Mobile View -->
                    <div class="space-y-3 lg:hidden">
                        <div class="flex items-center justify-between">
                            <span class="font-medium text-gray-500">No:</span>
                            <span class="font-semibold text-slate-800"><?php echo e($soal->firstItem() + $index); ?></span>
                        </div>
                        <div class="flex flex-col gap-1">
                            <span class="font-medium text-gray-500">Pertanyaan:</span>
                            <span class="text-slate-800 text-sm leading-relaxed"><?php echo e($s->pertanyaan); ?></span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="font-medium text-gray-500">Kesulitan:</span>
                            <?php if($s->difficulty === 'easy'): ?>
                                <span class="px-2.5 py-1 text-xs font-bold text-green-700 bg-green-50 rounded-full border border-green-200">Easy</span>
                            <?php elseif($s->difficulty === 'medium'): ?>
                                <span class="px-2.5 py-1 text-xs font-bold text-amber-700 bg-amber-50 rounded-full border border-amber-200">Medium</span>
                            <?php else: ?>
                                <span class="px-2.5 py-1 text-xs font-bold text-red-700 bg-red-50 rounded-full border border-red-200">Hard</span>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="font-medium text-gray-500">Kunci:</span>
                            <span class="px-3 py-1 text-xs font-bold text-white rounded-full bg-admin-green"><?php echo e(strtoupper($s->kunci_jawaban)); ?></span>
                        </div>
                        <div class="flex justify-end pt-3 mt-3 border-t border-slate-100">
                            <form action="<?php echo e(route('admin.quiz.destroySoal', $s->id_soal_quiz)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus soal ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="px-4 py-2 text-xs font-bold text-white transition bg-red-500 rounded-xl hover:bg-opacity-90">
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Desktop View -->
                    <div class="items-center hidden grid-cols-12 gap-4 text-center lg:grid font-jakarta text-slate-700">
                        <div class="col-span-1 font-semibold text-slate-800"><?php echo e($soal->firstItem() + $index); ?></div>
                        <div class="col-span-6 font-medium text-left text-sm leading-relaxed pr-4">
                            <?php echo e(Str::limit($s->pertanyaan, 100)); ?>

                        </div>
                        <div class="col-span-2">
                            <?php if($s->difficulty === 'easy'): ?>
                                <span class="px-3 py-1 text-xs font-bold text-green-700 bg-green-50 rounded-full border border-green-200">Easy</span>
                            <?php elseif($s->difficulty === 'medium'): ?>
                                <span class="px-3 py-1 text-xs font-bold text-amber-700 bg-amber-50 rounded-full border border-amber-200">Medium</span>
                            <?php else: ?>
                                <span class="px-3 py-1 text-xs font-bold text-red-700 bg-red-50 rounded-full border border-red-200">Hard</span>
                            <?php endif; ?>
                        </div>
                        <div class="col-span-1">
                            <span class="px-3 py-1 text-xs font-bold text-white rounded-full bg-admin-green"><?php echo e(strtoupper($s->kunci_jawaban)); ?></span>
                        </div>
                        <div class="col-span-2 flex justify-center">
                            <form action="<?php echo e(route('admin.quiz.destroySoal', $s->id_soal_quiz)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus soal ini?');" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="transition-opacity hover:opacity-80" title="Hapus Soal">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-admin-red fill-admin-red">
                                        <path d="M3 6h18"/>
                                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-8 text-center">
                    <p class="text-lg text-gray-500 font-jakarta">Belum ada soal terdaftar untuk quiz ini</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Kembali -->
        <div class="mt-8 text-center">
            <a href="<?php echo e(route('admin.quiz.index')); ?>" 
               class="inline-block px-8 py-3 text-lg font-bold text-slate-700 transition bg-slate-200 rounded-xl hover:bg-slate-300 font-jakarta">
                Kembali ke Daftar Quiz
            </a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/quiz/soal.blade.php ENDPATH**/ ?>