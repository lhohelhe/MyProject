<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>* { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 px-8 py-6 overflow-y-auto">

        
        <h1 class="mb-6 text-2xl font-black uppercase tracking-wider text-black border-b-4 border-black pb-2">Katalog Buku</h1>

        
        <?php if($buku->isEmpty()): ?>
            <p class="italic text-gray-400 font-jakarta">belum ada buku yang tersedia.</p>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('user.buku.show', $b->id_buku)); ?>" class="relative flex flex-col items-center bg-white border-2 border-black shadow-[4px_4px_0px_#000] rounded-xl overflow-hidden cursor-pointer hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">

    
    <div class="absolute z-10 top-2 left-2 bg-[#F4922A] text-white border-2 border-black rounded-full px-3 py-0.5 shadow-[2px_2px_0px_#000]">
        <span class="text-[11px] font-bold font-jakarta">
            Kelas <?php echo e($b->kelas); ?>

        </span>
    </div>

    
    <div class="w-full overflow-hidden border-b-2 border-black" style="aspect-ratio: 3/4;">
        <?php if($b->gambar): ?>
            <img src="<?php echo e(asset('storage/' . $b->gambar)); ?>"
                 alt="<?php echo e($b->judul_buku); ?>"
                 class="object-cover w-full h-full">
        <?php else: ?>
            <div class="flex items-center justify-center w-full h-full text-5xl bg-gray-100">
                <i data-lucide="book-open" class="w-16 h-16 text-gray-400"></i>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="w-full px-3 py-3 text-center bg-white">
        <p class="text-[11px] font-bold leading-tight text-black font-jakarta">
            <?php echo e($b->judul_buku); ?>

        </p>
    </div>

</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </main>
</div>
<script>
    if (typeof lucide !== 'undefined') lucide.createIcons();
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/user/katalog.blade.php ENDPATH**/ ?>