<?php $__env->startSection('title', 'Tambah Quiz - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10 text-slate-800">
            Tambah Quiz Baru
        </h1>

        <div class="max-w-2xl mx-auto bg-white shadow-md border border-slate-100 rounded-2xl p-6 sm:p-8">
            <form action="<?php echo e(route('admin.quiz.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Bab Selection -->
                <div>
                    <label for="id_bab" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                        Pilih Bab
                    </label>
                    <select id="id_bab" 
                            name="id_bab" 
                            class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                            required>
                        <option value="">-- Pilih Bab --</option>
                        <?php $__currentLoopData = $bab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id_bab); ?>" <?php echo e(old('id_bab') == $b->id_bab ? 'selected' : ''); ?>>
                                <?php echo e($b->buku->judul_buku ?? '-'); ?> — Bab <?php echo e($b->nomor_bab); ?>: <?php echo e($b->judul_bab); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_bab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Judul Quiz -->
                <div>
                    <label for="judul_quiz" class="block mb-2 text-sm font-semibold text-slate-700 font-jakarta">
                        Judul Quiz
                    </label>
                    <input type="text" 
                           id="judul_quiz" 
                           name="judul_quiz" 
                           class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                           placeholder="Masukkan judul quiz"
                           value="<?php echo e(old('judul_quiz')); ?>"
                           required>
                    <?php $__errorArgs = ['judul_quiz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Action Buttons -->
                <div class="flex flex-col gap-3 pt-6 sm:flex-row sm:justify-between">
                    <a href="<?php echo e(route('admin.quiz.index')); ?>" 
                       class="flex justify-center items-center px-6 py-3 text-lg font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition font-jakarta">
                        Batal
                    </a>
                    <button type="submit" 
                            class="flex justify-center items-center px-6 py-3 text-lg font-bold text-white bg-admin-orange rounded-xl hover:bg-opacity-90 transition font-jakarta">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/quiz/create.blade.php ENDPATH**/ ?>