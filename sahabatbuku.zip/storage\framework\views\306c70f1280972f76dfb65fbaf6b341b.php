<?php $__env->startSection('title', 'Generate Flashcard - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10 text-slate-800">
        Generate Flashcard
    </h1>

    
    <?php if(session('success')): ?>
        <div class="px-4 py-3 mb-6 text-green-800 bg-green-100 rounded-xl font-jakarta">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="px-4 py-3 mb-6 text-red-800 bg-red-100 rounded-xl font-jakarta">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="p-6 mb-8 bg-white rounded-2xl shadow-md border border-slate-100 font-jakarta">
        <form action="<?php echo e(route('admin.flashcard.generate')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-12 gap-4 mb-6">
                <div class="col-span-6">
                    <label class="block mb-1 font-medium text-slate-700" for="buku_id">Buku</label>
                    <select id="buku_id" name="buku_id" class="w-full border rounded px-3 py-2 text-slate-800" required>
                        <option value="">-- Pilih Buku --</option>
                        <?php $__currentLoopData = $bukuList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($buku->id_buku); ?>"><?php echo e($buku->judul_buku); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-span-6">
                    <label class="block mb-1 font-medium text-slate-700" for="id_bab">Bab</label>
                    <select id="id_bab" name="id_bab" class="w-full border rounded px-3 py-2 text-slate-800" disabled required>
                        <option value="">-- Pilih Bab --</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="px-4 py-2 bg-[#F4922A] text-white rounded hover:bg-[#d37a1e] transition-colors font-jakarta">
                Generate Flashcard dengan AI
            </button>
        </form>
    </div>

    
    <div class="overflow-hidden bg-white shadow-md rounded-2xl border border-slate-100 font-jakarta">
        <div class="p-6">
            <div class="hidden p-4 mb-4 rounded-lg bg-slate-50 lg:block border border-slate-100">
                <div class="grid grid-cols-12 gap-4 text-base font-semibold text-center text-slate-600">
                    <div class="col-span-1">No</div>
                    <div class="col-span-2 text-left">Bab</div>
                    <div class="col-span-2 text-left">Buku</div>
                    <div class="col-span-3 text-left">Pertanyaan</div>
                    <div class="col-span-3 text-left">Jawaban</div>
                    <div class="col-span-1">Aksi</div>
                </div>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $flashcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-4 mb-4 border border-slate-100 rounded-xl bg-white hover:shadow-sm transition-shadow">
                    <div class="grid grid-cols-12 gap-4 text-center lg:grid text-slate-700">
                        <div class="col-span-1 font-semibold text-slate-800"><?php echo e($flashcards->firstItem() + $index); ?></div>
                        <div class="col-span-2 text-left text-slate-800">
                            <?php echo e($fc->subab->bab->judul_bab ?? '-'); ?>

                        </div>
                        <div class="col-span-2 text-left text-slate-800">
                            <?php echo e($fc->subab->bab->buku->judul_buku ?? '-'); ?>

                        </div>
                        <div class="col-span-3 text-left text-slate-800">
                            <?php echo e(Str::limit($fc->pertanyaan, 80)); ?>

                        </div>
                        <div class="col-span-3 text-left text-slate-800">
                            <?php echo e(Str::limit($fc->jawaban, 100)); ?>

                        </div>
                        <div class="col-span-1 flex items-center justify-center">
                            <form action="<?php echo e(route('admin.flashcard.destroy', $fc->id_flashcard ?? $fc->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus flashcard ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800">
                                    <i data-lucide="trash-2"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-8 text-center bg-white rounded-2xl">
                    <p class="text-lg text-gray-500">Belum ada flashcard.</p>
                </div>
            <?php endif; ?>
        </div>
        <?php if($flashcards->hasPages()): ?>
            <div class="mt-8 px-6"><?php echo e($flashcards->links()); ?></div>
        <?php endif; ?>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const bukuSelect = document.getElementById('buku_id');
            const babSelect = document.getElementById('id_bab');

            bukuSelect.addEventListener('change', function () {
                const bukuId = this.value;
                babSelect.innerHTML = '<option value="">-- Pilih Bab --</option>';
                babSelect.disabled = true;
                if (bukuId) {
                    fetch(`/admin/bab/by-buku/${bukuId}`)
                        .then(res => res.json())
                        .then(data => {
                            data.forEach(bab => {
                                const opt = document.createElement('option');
                                opt.value = bab.id_bab;
                                opt.textContent = 'Bab ' + bab.nomor_bab + ': ' + bab.judul_bab;
                                babSelect.appendChild(opt);
                            });
                            babSelect.disabled = false;
                        })
                        .catch(() => console.error('Failed to load bab'));
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/flashcard/index.blade.php ENDPATH**/ ?>