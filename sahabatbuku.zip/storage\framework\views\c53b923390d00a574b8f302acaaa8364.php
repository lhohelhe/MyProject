<?php $__env->startSection('content'); ?>
<div class="flex h-screen overflow-hidden bg-[#E5F8FF]">
    
    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <div class="flex-1 flex flex-row font-jakarta h-screen overflow-hidden">
        
        <div class="flex-1 w-full mx-auto px-6 py-8 flex flex-col lg:flex-row gap-8 h-screen overflow-hidden">
            
            
            <aside class="w-full lg:w-[240px] shrink-0 h-[calc(100vh-4rem)] flex flex-col gap-3">
                
                <a href="<?php echo e(route('user.buku.show', $buku->id_buku)); ?>"
                   class="flex items-center gap-2 px-4 py-2.5 bg-white rounded-xl border border-slate-100 shadow-sm text-xs font-bold text-slate-600 hover:text-[#F4922A] hover:border-[#F4922A]/30 hover:bg-orange-50/50 transition-all shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                    <span class="truncate"><?php echo e($buku->judul_buku); ?></span>
                </a>

                <div class="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm flex flex-col max-h-full flex-1 min-h-0">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 shrink-0">Daftar Subbab</p>
                    <div class="overflow-y-auto flex-1 pr-1 space-y-1 scrollbar-thin">
                        <ul class="space-y-1">
                            <?php $__currentLoopData = $subbabList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isActive = ($sub->id_subbab == $materi->id_subbab);
                                    $firstMateri = $sub->materi->first();
                                    $materiLink = $firstMateri ? route('user.materi.baca', $firstMateri->id_materi) : '#';
                                ?>
                                <li>
                                    <a href="<?php echo e($materiLink); ?>" 
                                       class="flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition-all text-xs font-medium 
                                       <?php echo e($isActive ? 'bg-[#E5F8FF] text-[#F4922A] font-semibold' : 'text-slate-600 hover:bg-slate-50'); ?>">
                                        <div class="w-2 h-2 rounded-full shrink-0 <?php echo e($isActive ? 'bg-[#F4922A]' : 'bg-slate-300'); ?>"></div>
                                        <span class="truncate"><?php echo e($sub->judul_subbab); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </aside>


            
            <main class="flex-1 max-w-[720px] mx-auto w-full h-screen overflow-y-auto pb-24">
                <article class="bg-white rounded-3xl p-8 shadow-sm border border-slate-100/80">
                    <span class="inline-block bg-[#F4922A]/10 text-[#F4922A] text-[10px] font-bold px-3 py-1 rounded-lg mb-4 uppercase tracking-wider">
                        Materi Belajar
                    </span>
                    <h1 class="text-3xl font-extrabold text-slate-900 leading-tight mb-6 font-jakarta">
                        <?php echo e($materi->judul_materi); ?>

                    </h1>
                    
                    <div class="prose max-w-none text-slate-700 leading-relaxed font-serif text-lg space-y-5">
                        <?php echo $materi->isi; ?>

                    </div>

                    
                    <div class="flex items-center justify-between mt-10 pt-6 border-t border-slate-100">
                        <?php if($prev): ?>
                            <a href="<?php echo e(route('user.materi.baca', $prev->id_materi)); ?>" 
                               class="inline-flex items-center gap-2 px-5 py-3 text-sm font-bold text-[#F4922A] hover:bg-[#E5F8FF] rounded-xl transition-all">
                                <i data-lucide="arrow-left" class="w-4 h-4"></i> Sebelum
                            </a>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>

                        <?php if($next): ?>
                            <a href="<?php echo e(route('user.materi.baca', $next->id_materi)); ?>" 
                               class="inline-flex items-center gap-2 px-5 py-3 text-sm font-bold text-white bg-[#F4922A] hover:bg-opacity-95 rounded-xl transition-all shadow-md shadow-orange-200">
                                Lanjut <i data-lucide="arrow-right" class="w-4 h-4"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </article>
            </main>

            
            <aside class="w-full lg:w-[240px] shrink-0 space-y-4 h-screen overflow-y-hidden sticky top-0">
                <div class="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-5">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Progress Bab</p>
                        <div class="flex items-center justify-between mb-1.5">
                            <span class="text-xs font-semibold text-slate-500">Selesai Dibaca</span>
                            <span class="text-xs font-bold text-[#F4922A]"><?php echo e($progress); ?>%</span>
                        </div>
                        <div class="w-full bg-slate-100 rounded-full h-1.5">
                            <div class="h-1.5 rounded-full bg-[#F4922A] transition-all duration-500" style="width: <?php echo e($progress); ?>%"></div>
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">XP Diperoleh</p>
                            <p class="text-lg font-extrabold text-[#F4922A] mt-0.5"><?php echo e($userXp); ?> XP</p>
                        </div>
                        <div class="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-[#F4922A]">
                            <i data-lucide="award" class="w-5 h-5"></i>
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100 space-y-2">
                        <a href="<?php echo e(route('user.flashcard', $materi->subab->id_subbab)); ?>" 
                           class="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 transition-all border border-slate-200/50">
                            <i data-lucide="book-marked" class="w-4 h-4 text-slate-400"></i> Buka Flashcard
                        </a>
                        <a href="<?php echo e(route('user.quiz.index', $bab->id_bab)); ?>" 
                           class="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-xs font-bold text-[#1E3A5F] bg-blue-50 hover:bg-blue-100 transition-all border border-blue-200/30">
                            <i data-lucide="clipboard-list" class="w-4 h-4 text-[#1E3A5F]/80"></i> Kerjakan Quiz
                        </a>
                    </div>
                </div>
            </aside>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/user/materi-baca.blade.php ENDPATH**/ ?>