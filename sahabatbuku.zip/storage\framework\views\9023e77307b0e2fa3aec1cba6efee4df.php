

<?php $__env->startSection('title', 'Kelola Soal Simulasi - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10">
            Kelola Soal — <?php echo e($simulasi->judul_simulasi); ?>

        </h1>

        <!-- Info Soal -->
        <div class="p-4 mb-8 bg-white shadow-md rounded-xl lg:p-4">
            <p class="text-xl font-semibold text-gray-800 font-jakarta">
                Total Soal: <span class="ml-2"><?php echo e($soal->total()); ?></span>
            </p>
        </div>

        <!-- Form Tambah Soal -->
        <div class="p-6 mb-8 bg-white shadow-md rounded-2xl sm:p-8">
            <h2 class="mb-6 text-2xl font-bold text-gray-800 font-jakarta">Tambah Soal Baru</h2>
            
            <form action="/admin/simulasi/<?php echo e($simulasi->id_simulasi); ?>/soal" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_simulasi" value="<?php echo e($simulasi->id_simulasi); ?>">

                <!-- Pertanyaan -->
                <div>
                    <label for="pertanyaan" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Pertanyaan
                    </label>
                    <textarea id="pertanyaan" 
                              name="pertanyaan" 
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pertanyaan soal"
                              rows="4"
                              value="<?php echo e(old('pertanyaan')); ?>"
                              required></textarea>
                    <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Grid Opsi -->
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <!-- Opsi A -->
                    <div>
                        <label for="opsi_a" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi A
                        </label>
                        <input type="text" 
                               id="opsi_a" 
                               name="opsi_a" 
                               class="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi A"
                               value="<?php echo e(old('opsi_a')); ?>"
                               required>
                        <?php $__errorArgs = ['opsi_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Opsi B -->
                    <div>
                        <label for="opsi_b" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi B
                        </label>
                        <input type="text" 
                               id="opsi_b" 
                               name="opsi_b" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi B"
                               value="<?php echo e(old('opsi_b')); ?>"
                               required>
                        <?php $__errorArgs = ['opsi_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Opsi C -->
                    <div>
                        <label for="opsi_c" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi C
                        </label>
                        <input type="text" 
                               id="opsi_c" 
                               name="opsi_c" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi C"
                               value="<?php echo e(old('opsi_c')); ?>"
                               required>
                        <?php $__errorArgs = ['opsi_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Opsi D -->
                    <div>
                        <label for="opsi_d" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi D
                        </label>
                        <input type="text" 
                               id="opsi_d" 
                               name="opsi_d" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi D"
                               value="<?php echo e(old('opsi_d')); ?>"
                               required>
                        <?php $__errorArgs = ['opsi_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Kunci Jawaban -->
                <div>
                    <label for="kunci_jawaban" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Kunci Jawaban
                    </label>
                    <select id="kunci_jawaban" 
                            name="kunci_jawaban" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                            required>
                        <option value="">-- Pilih Jawaban Benar --</option>
                        <option value="a" <?php echo e(old('kunci_jawaban') === 'a' ? 'selected' : ''); ?>>A</option>
                        <option value="b" <?php echo e(old('kunci_jawaban') === 'b' ? 'selected' : ''); ?>>B</option>
                        <option value="c" <?php echo e(old('kunci_jawaban') === 'c' ? 'selected' : ''); ?>>C</option>
                        <option value="d" <?php echo e(old('kunci_jawaban') === 'd' ? 'selected' : ''); ?>>D</option>
                    </select>
                    <?php $__errorArgs = ['kunci_jawaban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Pembahasan -->
                <div>
                    <label for="pembahasan" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Pembahasan <span class="text-gray-500">(Opsional)</span>
                    </label>
                    <textarea id="pembahasan" 
                              name="pembahasan" 
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pembahasan soal"
                              rows="4"
                              value="<?php echo e(old('pembahasan')); ?>"></textarea>
                    <?php $__errorArgs = ['pembahasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="block mt-2 text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tombol Submit -->
                <div class="flex justify-end">
                    <button type="submit" 
                            class="px-6 py-3 text-lg font-bold text-black transition rounded-lg bg-admin-orange hover:bg-opacity-90 font-jakarta">
                        Tambah Soal
                    </button>
                </div>
            </form>
        </div>

        <!-- Daftar Soal -->
        <div class="overflow-hidden bg-white shadow-md rounded-2xl">
            <div class="p-6">
                <h2 class="mb-6 text-2xl font-bold text-gray-800 font-jakarta">Daftar Soal</h2>

                <!-- Header Tabel Desktop -->
                <div class="hidden p-4 mb-4 rounded-lg bg-gray-50 lg:block">
                    <div class="grid grid-cols-12 gap-4 text-lg font-semibold text-center font-jakarta">
                        <div>No</div>
                        <div class="col-span-7 text-left">Pertanyaan</div>
                        <div>Kunci</div>
                        <div class="col-span-3">Aksi</div>
                    </div>
                </div>

                <!-- List Soal -->
                <?php $__empty_1 = true; $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-4 mb-4 border border-gray-200 rounded-lg">
                    
                    <!-- Mobile View -->
                    <div class="space-y-3 lg:hidden">
                        <div class="flex items-center justify-between">
                            <span class="font-medium text-gray-600">No:</span>
                            <span class="font-medium"><?php echo e($loop->iteration); ?></span>
                        </div>
                        <div class="flex items-start justify-between">
                            <span class="font-medium text-gray-600">Pertanyaan:</span>
                            <span class="max-w-xs text-right"><?php echo e(Str::limit($s->pertanyaan, 50)); ?></span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="font-medium text-gray-600">Kunci:</span>
                            <span class="px-3 py-1 text-sm font-bold text-white rounded-full bg-admin-green"><?php echo e(strtoupper($s->kunci_jawaban)); ?></span>
                        </div>
                        <div class="flex justify-center pt-4 mt-4 border-t">
                            <form action="/admin/simulasi/soal/<?php echo e($s->id_soal_simulasi); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus soal ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="transition-opacity hover:opacity-80">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                         class="text-admin-red fill-admin-red">
                                        <path d="M3 6h18"/>
                                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Desktop View -->
                    <div class="items-center hidden grid-cols-12 gap-4 text-center lg:grid font-jakarta">
                        <div class="font-medium"><?php echo e($loop->iteration); ?></div>
                        <div class="col-span-7 font-medium text-left"><?php echo e(Str::limit($s->pertanyaan, 50)); ?></div>
                        <div>
                            <span class="px-3 py-1 text-sm font-bold text-white rounded-full bg-admin-green"><?php echo e(strtoupper($s->kunci_jawaban)); ?></span>
                        </div>
                        <div class="flex justify-center col-span-3">
                            <form action="/admin/simulasi/soal/<?php echo e($s->id_soal_simulasi); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus soal ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="transition-opacity hover:opacity-80">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                         class="text-admin-red fill-admin-red">
                                        <path d="M3 6h18"/>
                                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-8 text-center">
                    <p class="text-lg text-gray-500 font-jakarta">Belum ada soal terdaftar</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Kembali -->
        <div class="mt-8 text-center">
            <a href="<?php echo e(route('simulasi.index')); ?>" 
               class="inline-block px-8 py-3 text-lg font-bold text-gray-700 transition bg-gray-300 rounded-lg hover:bg-opacity-90 font-jakarta">
                Kembali
            </a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/soal-simulasi/index.blade.php ENDPATH**/ ?>