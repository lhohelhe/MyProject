<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Harian - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>* { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 px-8 py-6 overflow-y-auto">

        
        <h1 class="mb-6 text-2xl font-black uppercase tracking-wider text-black border-b-4 border-black pb-2">Quiz Harian — <?php echo e($bab->judul_bab); ?></h1>

        
        <div class="flex flex-col items-start justify-between gap-4 p-4 mb-8 bg-white border-2 border-black shadow-[4px_4px_0px_#000] rounded-xl sm:flex-row sm:items-center">
            <div class="flex items-center gap-4">
                <span class="text-sm font-bold text-black font-jakarta">Kesulitan Saat Ini:</span>
                <?php
                    $diffLevel = $progress?->difficulty_level ?? 'easy';
                    $difficultyLabel = [
                        'easy' => 'Mudah',
                        'medium' => 'Sedang',
                        'hard' => 'Sulit'
                    ][$diffLevel] ?? 'Mudah';
                    $difficultyColor = [
                        'easy' => 'bg-green-500',
                        'medium' => 'bg-yellow-500',
                        'hard' => 'bg-red-500'
                    ][$diffLevel] ?? 'bg-green-500';
                ?>
                <span class="px-3 py-0.5 text-sm font-bold text-white border-2 border-black rounded-full <?php echo e($difficultyColor); ?> font-jakarta shadow-[2px_2px_0px_#000]">
                    <?php echo e($difficultyLabel); ?>

                </span>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-sm font-bold text-black font-jakarta">Streak Hari:</span>
                <span class="text-2xl font-black text-[#F4922A] font-jakarta">
                    <?php echo e($progress?->streak_hari ?? 0); ?> <i data-lucide="flame" class="w-6 h-6 inline-block mb-1"></i>
                </span>
            </div>
        </div>

        
        <?php if($quizList->isEmpty()): ?>
            <p class="italic text-gray-400 font-jakarta">belum ada quiz untuk bab ini.</p>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                <?php $__currentLoopData = $quizList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col bg-white border-2 border-black shadow-[4px_4px_0px_#000] rounded-xl overflow-hidden hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">

                    
                    <div class="relative px-4 py-4 bg-gradient-to-r from-blue-50 to-blue-100 border-b-2 border-black">
                        <div class="flex items-start justify-between gap-2 mb-2">
                            <h3 class="flex-1 text-sm font-black text-black line-clamp-2 font-jakarta">
                                <?php echo e($quiz->judul_quiz); ?>

                            </h3>
                            <?php
                                $qDifficulty = $quiz->difficulty ?? 'easy';
                                $qDifficultyLabel = [
                                    'easy' => 'Mudah',
                                    'medium' => 'Sedang',
                                    'hard' => 'Sulit'
                                ][$qDifficulty] ?? 'Mudah';
                                $qDifficultyBg = [
                                    'easy' => 'bg-green-500',
                                    'medium' => 'bg-yellow-500',
                                    'hard' => 'bg-red-500'
                                ][$qDifficulty] ?? 'bg-green-500';
                            ?>
                            <span class="px-2.5 py-0.5 text-xs font-bold text-white border-2 border-black rounded-full <?php echo e($qDifficultyBg); ?> whitespace-nowrap shadow-[2px_2px_0px_#000]">
                                <?php echo e($qDifficultyLabel); ?>

                            </span>
                        </div>
                    </div>

                    
                    <div class="flex-1 px-4 py-4">
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-black font-bold font-jakarta">Jumlah Soal</span>
                            <span class="text-sm font-black text-black font-jakarta"><?php echo e($quiz->jumlah_soal); ?> soal</span>
                        </div>
                    </div>

                    
                    <div class="px-4 py-3 border-t-2 border-black bg-slate-50">
                        <a href="<?php echo e(route('user.quiz.start', $quiz->id_quiz)); ?>" 
                           class="block w-full py-2 text-sm font-bold text-center text-white bg-[#F4922A] border-2 border-black rounded-xl shadow-[3px_3px_0px_#000] hover:shadow-none hover:translate-x-[3px] hover:translate-y-[3px] transition font-jakarta">
                            Mulai Quiz
                        </a>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </main>
</div>
<script>
    if (typeof lucide !== 'undefined') lucide.createIcons();
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/user/quiz/index.blade.php ENDPATH**/ ?>