<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-[#F5F5F5] min-h-screen">
    <?php echo $__env->yieldContent('content'); ?>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/layouts/user.blade.php ENDPATH**/ ?>