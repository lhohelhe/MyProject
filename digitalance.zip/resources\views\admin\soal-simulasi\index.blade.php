<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Soal Simulasi - SahabatBuku</title>
    @vite('resources/css/app.css')
</head>
<body class="bg-[#F5F5F5]">
<div class="flex flex-col min-h-screen lg:flex-row">
    <x-admin-sidebar />
    <main class="flex-1 p-4 sm:p-6 lg:p-16">
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10">
            Kelola Soal Simulasi
        </h1>

        <!-- Info Simulasi -->
        <div class="p-4 mb-6 bg-white shadow-md rounded-xl sm:p-6">
            <div class="flex flex-col items-start justify-between gap-4 lg:flex-row lg:items-center">
                <div>
                    <p class="text-sm text-gray-600 font-jakarta">Simulasi:</p>
                    <p class="text-2xl font-bold text-gray-800 font-jakarta">{{ $simulasi->judul_simulasi }}</p>
                </div>
                <a href="{{ route('simulasi.index') }}" class="px-4 py-2 text-gray-700 bg-gray-300 rounded-lg hover:bg-opacity-90 transition font-jakarta">
                    ← Kembali
                </a>
            </div>
        </div>

        <!-- Form Tambah Soal -->
        <div class="mb-8 bg-white shadow-md rounded-2xl p-6 sm:p-8">
            <h2 class="mb-6 text-2xl font-bold text-gray-800 font-jakarta">Tambah Soal Baru</h2>
            
            <form action="{{ route('soal-simulasi.store', $simulasi->id_simulasi) }}" method="POST" class="space-y-6">
                @csrf

                <!-- Pertanyaan -->
                <div>
                    <label for="pertanyaan" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Pertanyaan
                    </label>
                    <textarea id="pertanyaan" 
                              name="pertanyaan" 
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pertanyaan soal"
                              rows="4"
                              value="{{ old('pertanyaan') }}"
                              required></textarea>
                    @error('pertanyaan')
                        <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Grid Opsi -->
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <!-- Opsi A -->
                    <div>
                        <label for="opsi_a" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi A
                        </label>
                        <input type="text" 
                               id="opsi_a" 
                               name="opsi_a" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi A"
                               value="{{ old('opsi_a') }}"
                               required>
                        @error('opsi_a')
                            <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Opsi B -->
                    <div>
                        <label for="opsi_b" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi B
                        </label>
                        <input type="text" 
                               id="opsi_b" 
                               name="opsi_b" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi B"
                               value="{{ old('opsi_b') }}"
                               required>
                        @error('opsi_b')
                            <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Opsi C -->
                    <div>
                        <label for="opsi_c" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi C
                        </label>
                        <input type="text" 
                               id="opsi_c" 
                               name="opsi_c" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi C"
                               value="{{ old('opsi_c') }}"
                               required>
                        @error('opsi_c')
                            <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Opsi D -->
                    <div>
                        <label for="opsi_d" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                            Opsi D
                        </label>
                        <input type="text" 
                               id="opsi_d" 
                               name="opsi_d" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                               placeholder="Masukkan opsi D"
                               value="{{ old('opsi_d') }}"
                               required>
                        @error('opsi_d')
                            <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <!-- Kunci Jawaban -->
                <div>
                    <label for="kunci_jawaban" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Kunci Jawaban
                    </label>
                    <select id="kunci_jawaban" 
                            name="kunci_jawaban" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                            required>
                        <option value="">-- Pilih Jawaban Benar --</option>
                        <option value="a" {{ old('kunci_jawaban') === 'a' ? 'selected' : '' }}>A</option>
                        <option value="b" {{ old('kunci_jawaban') === 'b' ? 'selected' : '' }}>B</option>
                        <option value="c" {{ old('kunci_jawaban') === 'c' ? 'selected' : '' }}>C</option>
                        <option value="d" {{ old('kunci_jawaban') === 'd' ? 'selected' : '' }}>D</option>
                    </select>
                    @error('kunci_jawaban')
                        <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Pembahasan -->
                <div>
                    <label for="pembahasan" class="block mb-2 text-lg font-semibold text-gray-800 font-jakarta">
                        Pembahasan <span class="text-gray-500">(Opsional)</span>
                    </label>
                    <textarea id="pembahasan" 
                              name="pembahasan" 
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-admin-orange"
                              placeholder="Masukkan pembahasan soal"
                              rows="4"
                              value="{{ old('pembahasan') }}"></textarea>
                    @error('pembahasan')
                        <span class="block mt-2 text-sm text-red-500">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Tombol Submit -->
                <div class="flex justify-end">
                    <button type="submit" 
                            class="px-6 py-3 text-lg font-bold text-black bg-admin-orange rounded-lg hover:bg-opacity-90 transition font-jakarta">
                        Tambah Soal
                    </button>
                </div>
            </form>
        </div>

        <!-- Daftar Soal yang Ada -->
        <div class="bg-white shadow-md rounded-2xl p-6 sm:p-8">
            <h2 class="mb-6 text-2xl font-bold text-gray-800 font-jakarta">Daftar Soal</h2>

            @forelse($soal as $index => $s)
            <div class="p-4 mb-4 border-l-4 border-admin-orange bg-gray-50 rounded-lg sm:p-6">
                <div class="space-y-4">
                    <!-- Nomor dan Pertanyaan -->
                    <div>
                        <p class="text-sm font-medium text-gray-600 font-jakarta">Soal {{ ($soal->currentPage() - 1) * $soal->perPage() + $index + 1 }}</p>
                        <p class="mt-1 text-lg font-semibold text-gray-800">{{ $s->pertanyaan }}</p>
                    </div>

                    <!-- Opsi-opsi -->
                    <div class="grid grid-cols-1 gap-2 md:grid-cols-2">
                        <div class="p-3 bg-white rounded border border-gray-200">
                            <span class="font-semibold text-gray-600">A.</span> {{ $s->opsi_a }}
                            @if($s->kunci_jawaban === 'a')
                                <span class="ml-2 text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded">✓ Benar</span>
                            @endif
                        </div>
                        <div class="p-3 bg-white rounded border border-gray-200">
                            <span class="font-semibold text-gray-600">B.</span> {{ $s->opsi_b }}
                            @if($s->kunci_jawaban === 'b')
                                <span class="ml-2 text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded">✓ Benar</span>
                            @endif
                        </div>
                        <div class="p-3 bg-white rounded border border-gray-200">
                            <span class="font-semibold text-gray-600">C.</span> {{ $s->opsi_c }}
                            @if($s->kunci_jawaban === 'c')
                                <span class="ml-2 text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded">✓ Benar</span>
                            @endif
                        </div>
                        <div class="p-3 bg-white rounded border border-gray-200">
                            <span class="font-semibold text-gray-600">D.</span> {{ $s->opsi_d }}
                            @if($s->kunci_jawaban === 'd')
                                <span class="ml-2 text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded">✓ Benar</span>
                            @endif
                        </div>
                    </div>

                    <!-- Pembahasan -->
                    @if($s->pembahasan)
                    <div class="p-3 bg-blue-50 rounded border border-blue-200">
                        <p class="text-sm font-semibold text-blue-800 mb-1">Pembahasan:</p>
                        <p class="text-gray-700">{{ $s->pembahasan }}</p>
                    </div>
                    @endif

                    <!-- Tombol Hapus -->
                    <div class="flex justify-end pt-2 border-t">
                        <form action="{{ route('soal-simulasi.destroy', [$simulasi->id_simulasi, $s->id_soal_simulasi]) }}" 
                              method="POST" 
                              onsubmit="return confirm('Yakin ingin menghapus soal ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" 
                                    class="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-red-500 rounded-lg hover:bg-opacity-90 transition">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                     viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                     class="text-admin-red fill-admin-red">
                                    <path d="M3 6h18"/>
                                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                                </svg>
                                Hapus
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            @empty
            <div class="p-6 text-center bg-gray-50 rounded-lg">
                <p class="text-lg text-gray-500">Belum ada soal untuk simulasi ini</p>
            </div>
            @endforelse

            <!-- Pagination -->
            <div class="mt-8">
                {{ $soal->links() }}
            </div>
        </div>
    </main>
</div>
</body>
</html>
