<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Saran - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-[#F8FAFC] antialiased">
    <div class="flex min-h-screen">
        <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>

        <main class="flex-1 p-8 overflow-y-auto">
            <?php if(session('success')): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-4 py-3 mb-6">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="flex items-center justify-between mb-8">
                <div class="flex items-center gap-3">
                    <div class="p-2 bg-white rounded-xl shadow-sm border border-slate-100">
                        <i data-lucide="message-square" class="w-6 h-6 text-slate-600"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-slate-800 flex items-center gap-3">
                            Kelola Saran
                            <?php $unread = \App\Models\Saran::where('status', 'belum_dibaca')->count(); ?>
                            <?php if($unread > 0): ?>
                                <span class="bg-orange-100 text-orange-600 text-xs font-semibold px-3 py-1 rounded-full">
                                    <?php echo e($unread); ?> belum dibaca
                                </span>
                            <?php endif; ?>
                        </h1>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-100">
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">No.</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Saran</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $sarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $saran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($loop->even ? 'bg-slate-50/30' : 'bg-white'); ?> hover:bg-slate-50 transition-colors">
                                <td class="px-6 py-4 text-sm text-slate-500">
                                    <?php echo e($sarans->firstItem() + $index); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <p class="text-sm text-slate-700 max-w-md line-clamp-2" title="<?php echo e($saran->isi); ?>">
                                        <?php echo e($saran->isi); ?>

                                    </p>
                                </td>
                                <td class="px-6 py-4 text-xs text-slate-400">
                                    <?php echo e($saran->created_at->format('d M Y H:i')); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php if($saran->status === 'belum_dibaca'): ?>
                                        <span class="bg-orange-100 text-orange-600 text-xs font-semibold px-2 py-0.5 rounded-full">Belum Dibaca</span>
                                    <?php else: ?>
                                        <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-0.5 rounded-full">Sudah Dibaca</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 flex gap-2">
                                    <?php if($saran->status === 'belum_dibaca'): ?>
                                        <form action="<?php echo e(route('admin.saran.read', $saran->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="bg-blue-50 text-blue-600 text-xs px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors">
                                                Tandai Dibaca
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('admin.saran.destroy', $saran->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus saran ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="bg-red-50 text-red-500 text-xs px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-6 py-12 text-center">
                                    <div class="flex flex-col items-center justify-center space-y-3">
                                        <i data-lucide="inbox" class="w-12 h-12 text-slate-300"></i>
                                        <p class="text-slate-500 font-medium">Belum ada saran masuk</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if($sarans->hasPages()): ?>
                    <div class="px-6 py-4 border-t border-slate-100">
                        <?php echo e($sarans->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/admin/saran/index.blade.php ENDPATH**/ ?>