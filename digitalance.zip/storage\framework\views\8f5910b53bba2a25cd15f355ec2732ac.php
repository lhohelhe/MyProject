<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">
    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
    <main class="flex-1 px-10 py-8">
        
        <div class="mb-12">
            <h2 class="text-3xl font-extrabold text-black font-jakarta sm:text-4xl">
                halo, <?php echo e($user->name); ?>! 👋
            </h2>
            <p class="mt-2 text-lg text-gray-600 font-jakarta">
                selamat datang di sahabatbuku. mulai belajar sekarang juga.
            </p>
        </div>

        
        <div class="mb-12">
            <div class="p-8 bg-white shadow-md rounded-xl">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500 font-jakarta">total buku tersedia</p>
                        <p class="text-5xl font-extrabold text-black font-jakarta mt-2"><?php echo e($total_buku); ?></p>
                    </div>
                    <div class="text-6xl">📚</div>
                </div>
            </div>
        </div>

        
        <div class="mb-12">
            <h3 class="mb-6 text-2xl font-bold text-black font-jakarta">jelajahi kategori</h3>
            <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="#" class="block p-4 text-center text-white transition-colors bg-orange-400 rounded-xl hover:bg-orange-500 font-jakarta">
                        <p class="font-medium truncate"><?php echo e($kat->nama_kategori); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="col-span-full text-gray-500 font-jakarta">belum ada kategori</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div>
            <h3 class="mb-6 text-2xl font-bold text-black font-jakarta">buku terbaru</h3>
            
            <?php if($buku_terbaru->isEmpty()): ?>
                <div class="p-8 text-center bg-white rounded-xl">
                    <p class="text-gray-500 font-jakarta">belum ada buku yang ditambahkan</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                    <?php $__currentLoopData = $buku_terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#" class="group">
                            <div class="overflow-hidden bg-white shadow-md rounded-xl hover:shadow-lg transition-shadow">
                                
                                
                                <?php if($buku->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $buku->gambar)); ?>"
                                         alt="<?php echo e($buku->judul_buku); ?>"
                                         class="object-cover w-full h-56 group-hover:opacity-90 transition-opacity"
                                         style="aspect-ratio: 717 / 1027;">
                                <?php else: ?>
                                    <div class="flex items-center justify-center w-full h-56 text-5xl bg-gray-100 text-gray-300">
                                        📖
                                    </div>
                                <?php endif; ?>

                                
                                <div class="p-3">
                                    <p class="font-semibold text-sm text-black line-clamp-2 font-jakarta">
                                        <?php echo e($buku->judul_buku); ?>

                                    </p>
                                    <p class="text-xs text-gray-500 mt-2 font-jakarta">
                                        <?php echo e($buku->kategori->nama_kategori ?? '-'); ?>

                                    </p>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/user/dashboard.blade.php ENDPATH**/ ?>