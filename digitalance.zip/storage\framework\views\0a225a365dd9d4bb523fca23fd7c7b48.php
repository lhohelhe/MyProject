<!-- Sidebar -->
<aside class="flex-shrink-0 w-full lg:w-52 lg:h-screen lg:sticky lg:top-0 bg-admin-sidebar overflow-y-auto">
    <div class="p-4 lg:p-6">
        <!-- Logo -->
        <div class="flex items-center gap-2 mb-6 lg:mb-12">
            <img src="<?php echo e(asset('images/logo_2.png')); ?>" alt="SahabatBuku Logo" class="w-5 h-5 lg:w-5 lg:h-5"/>
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
            </svg>
        </div>
        <nav class="space-y-4">
            
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->routeIs('admin.dashboard') ? 'font-bold text-admin-orange' : ''); ?>">
                Dashboard
            </a>

            
            <a href="<?php echo e(route('dashboard-user.index')); ?>" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->routeIs('dashboard-user.*') ? 'font-bold text-admin-orange' : ''); ?>">
                Data User
            </a>

            
            <a href="<?php echo e(route('dashboard-buku.index')); ?>" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->routeIs('dashboard-buku.*') ? 'font-bold text-admin-orange' : ''); ?>">
                Data Buku
            </a>

            
            <a href="<?php echo e(route('simulasi.index')); ?>" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->routeIs('simulasi.*') || request()->routeIs('soal-simulasi.*') ? 'font-bold text-admin-orange' : ''); ?>">
                Simulasi Ujian
            </a>

            
            <a href="/admin/quiz" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->is('admin/quiz*') ? 'font-bold text-admin-orange' : ''); ?>">
                Data Quiz
            </a>

            
            <a href="/admin/flashcard" class="block text-base text-white transition lg:text-lg font-jakarta hover:text-admin-orange <?php echo e(request()->is('admin/flashcard*') ? 'font-bold text-admin-orange' : ''); ?>">
                Data Flashcard
            </a>
        </nav>
    </div>
</aside>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    lucide.createIcons();
</script><?php /**PATH C:\xampp\htdocs\MyProject\resources\views/components/admin-sidebar.blade.php ENDPATH**/ ?>