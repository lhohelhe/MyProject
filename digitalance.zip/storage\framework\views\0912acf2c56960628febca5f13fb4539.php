<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 px-8 py-8 overflow-y-auto">

        
        <h1 class="mb-6 text-2xl font-bold text-black font-jakarta">Katalog Buku</h1>

        
        <?php if($buku->isEmpty()): ?>
            <p class="italic text-gray-400 font-jakarta">belum ada buku yang tersedia.</p>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('user.buku.show', $b->id_buku)); ?>" class="relative flex flex-col items-center bg-white rounded-[12px] shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] overflow-hidden cursor-pointer hover:shadow-[0px_6px_16px_0px_rgba(0,0,0,0.2)] transition-shadow">

    
    <div class="absolute z-10 top-2 left-2 bg-[#F0924E] text-white rounded-[8px] px-2 py-1 shadow-[0px_3px_10px_0px_rgba(0,0,0,0.25)]">
        <span class="text-[13px] font-bold" style="font-family: 'Times New Roman', serif;">
            <?php echo e($b->kelas); ?>

        </span>
    </div>

    
    <div class="w-full overflow-hidden" style="aspect-ratio: 3/4;">
        <?php if($b->gambar): ?>
            <img src="<?php echo e(Storage::url($b->gambar)); ?>"
                 alt="<?php echo e($b->judul_buku); ?>"
                 class="object-cover w-full h-full">
        <?php else: ?>
            <div class="flex items-center justify-center w-full h-full text-5xl bg-gray-100">
                <i data-lucide="book-open" class="w-16 h-16 text-gray-400"></i>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="w-full px-3 py-3 text-center">
        <p class="text-[11px] font-light leading-tight text-black font-jakarta">
            <?php echo e($b->judul_buku); ?>

        </p>
    </div>

</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\MyProject\resources\views/user/katalog.blade.php ENDPATH**/ ?>