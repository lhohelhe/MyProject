<?php $__env->startSection('title', 'Tambah Bab - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="mb-6 text-3xl font-extrabold font-jakarta">tambah bab baru</h1>

        <div class="max-w-xl p-8 bg-white shadow-md rounded-xl">
            <form method="POST" action="<?php echo e(route('bab.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_buku" value="<?php echo e($id_buku); ?>">

                
                <div class="mb-5">
                    <label class="block mb-2 text-sm font-medium font-jakarta">nomor bab</label>
                    <input type="number"
                           name="nomor_bab"
                           value="<?php echo e(old('nomor_bab')); ?>"
                           placeholder="contoh: 1"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl font-jakarta focus:outline-none focus:ring-2 focus:ring-admin-orange">
                    <?php $__errorArgs = ['nomor_bab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-8">
                    <label class="block mb-2 text-sm font-medium font-jakarta">judul bab</label>
                    <input type="text"
                           name="judul_bab"
                           value="<?php echo e(old('judul_bab')); ?>"
                           placeholder="contoh: pengenalan sistem"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl font-jakarta focus:outline-none focus:ring-2 focus:ring-admin-orange">
                    <?php $__errorArgs = ['judul_bab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex gap-3">
                    <button type="submit"
                           class="px-6 py-3 font-bold text-black bg-admin-orange rounded-xl hover:bg-opacity-90 font-jakarta">
                        simpan bab
                    </button>
                    <a href="<?php echo e(url()->previous()); ?>"
                       class="px-6 py-3 font-bold text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 font-jakarta">
                        batal
                    </a>
                </div>
            </form>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/bab/create.blade.php ENDPATH**/ ?>