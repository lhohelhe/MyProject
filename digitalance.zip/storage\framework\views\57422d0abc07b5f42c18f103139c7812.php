<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SahabatBuku - Belajar Kurikulum Resmi Kemendikbud</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .font-jakarta {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        /* Asymmetric decorations */
        .decor-blob {
            border-radius: 40% 60% 70% 30% / 40% 50% 60% 50%;
        }
    </style>
</head>
<body class="antialiased font-jakarta bg-white">

    
    <header class="fixed top-6 left-0 right-0 w-full z-50 px-4 sm:px-6 flex justify-center">
        <div class="w-full max-w-5xl bg-white/60 backdrop-blur-md border border-white/50 shadow-lg rounded-full px-6 py-3 flex items-center justify-between">
            <a href="/" class="flex items-center">
                <img src="<?php echo e(asset('images/logo_1.png')); ?>" class="h-7" alt="SahabatBuku Logo">
            </a>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('login')); ?>" class="border border-slate-300 text-slate-700 hover:bg-slate-50 transition rounded-xl px-5 py-2 text-sm font-semibold">
                    Masuk
                </a>
                <a href="<?php echo e(route('register')); ?>" class="bg-[#F4922A] hover:bg-orange-600 text-white transition rounded-xl px-5 py-2 text-sm font-semibold">
                    Daftar
                </a>
            </div>
        </div>
    </header>

    
    <section class="relative bg-[#E5F8FF] pt-28 pb-16 lg:pt-36 lg:pb-24 px-6 lg:px-8 overflow-hidden">
        
        <div class="absolute right-[-10%] top-[-10%] w-[500px] h-[500px] bg-sky-200/50 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute left-[-5%] bottom-[-5%] w-[300px] h-[300px] bg-orange-100/50 rounded-full blur-2xl pointer-events-none"></div>

        <div class="max-w-7xl mx-auto relative z-10">
            
            <div class="text-center mb-20 lg:mb-32 mt-4 lg:mt-8">
                <h1 class="text-5xl md:text-7xl lg:text-[6rem] font-extrabold text-slate-900 tracking-tight leading-none mb-6">
                    Fokus. <span class="italic font-light text-slate-600" style="font-family: Georgia, serif;">Paham.</span> Lulus.
                </h1>
                <p class="text-slate-500 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
                    belajar, pahami konsepnya, dan capai kelulusanmu dengan mudah.
                </p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div class="lg:col-span-6 space-y-6">
                
                <h2 class="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-800 leading-tight">
                    Belajar Langsung dari<br>
                    Buku Resmi<br>
                    <span class="relative inline-block text-[#F4922A]">
                        Kemendikdasmen
                        <span class="absolute left-0 -bottom-2 w-full">
                            <svg viewBox="0 0 100 10" preserveAspectRatio="none" class="w-full h-2.5">
                                <path d="M0,5 Q20,10 40,5 T80,5 T100,5" fill="none" stroke="#F4922A" stroke-width="4" stroke-linecap="round"/>
                            </svg>
                        </span>
                    </span>
                </h2>

                <p class="text-slate-500 text-base md:text-lg max-w-md leading-relaxed">
                    Platform pembelajaran terarah bersumber pada buku tematik
                </p>

                <div class="flex items-center gap-4 pt-4">
                    <a href="<?php echo e(route('register')); ?>" class="bg-[#F4922A] hover:bg-orange-600 text-white rounded-2xl px-7 py-3.5 font-bold text-base shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 hover:scale-[1.02] transition duration-200">
                        Mulai Belajar Gratis
                    </a>
                    <a href="#features" class="text-slate-600 text-base font-semibold underline underline-offset-4 hover:text-[#F4922A] transition">
                        Lihat Fitur
                    </a>
                </div>
            </div>

            
            <div class="lg:col-span-6 flex justify-center">
                <div class="relative w-full max-w-md lg:max-w-lg px-4">
                    
                    <div class="absolute inset-0 bg-[#F4922A] rounded-[2rem] rotate-3 scale-95 opacity-10"></div>
                    <div class="absolute inset-0 bg-[#1E3A5F] rounded-[2rem] -rotate-2 scale-95 opacity-5"></div>
                    
                    
                    <img src="<?php echo e(asset('images/hero_student.png')); ?>" 
                         class="w-full h-[380px] md:h-[500px] object-cover rounded-[2rem] shadow-2xl relative z-10 border-4 border-white"
                         alt="Siswa SMA belajar">

                    
                    <div class="bg-white rounded-2xl px-4 py-3 shadow-lg absolute -left-6 top-8 z-20 border border-slate-100 animate-bounce" style="animation-duration: 3s;">
                        <span class="text-xs font-bold text-slate-700 flex items-center gap-1">
                            ✅ Berbasis Kurikulum Resmi
                        </span>
                    </div>

                    
                    <div class="bg-[#F4922A] text-white rounded-2xl px-4 py-3 shadow-lg absolute -right-4 bottom-8 z-20 hover:scale-105 transition">
                        <span class="text-xs font-bold flex items-center gap-1">
                            🏆 XP & Level System
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="w-full bg-[#1E3A5F] py-8 px-8">
        <div class="max-w-7xl mx-auto">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-16 text-center">
                <div class="space-y-1">
                    <p class="text-4xl lg:text-5xl font-extrabold text-white">4+</p>
                    <p class="text-sm text-blue-200 font-medium">Fitur Belajar</p>
                </div>
                <div class="space-y-1">
                    <p class="text-4xl lg:text-5xl font-extrabold text-white">100%</p>
                    <p class="text-sm text-blue-200 font-medium">Buku Resmi</p>
                </div>
                <div class="space-y-1">
                    <p class="text-4xl lg:text-5xl font-extrabold text-white">3</p>
                    <p class="text-sm text-blue-200 font-medium">Kelas (X-XII)</p>
                </div>
                <div class="space-y-1">
                    <p class="text-4xl lg:text-5xl font-extrabold text-white">∞</p>
                    <p class="text-sm text-blue-200 font-medium">Akses Gratis</p>
                </div>
            </div>
        </div>
    </section>

    
    <section id="features" class="bg-white py-20 px-8 relative">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-12">
                <h2 class="text-3xl lg:text-4xl font-extrabold text-slate-800 font-jakarta">
                    Kenapa SahabatBuku?
                </h2>
                <p class="text-slate-500 text-base mt-2 max-w-md mx-auto">
                    Dirancang khusus untuk siswa SMA yang ingin belajar terarah dan siap ujian.
                </p>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-6">
                
                <div class="bg-[#E5F8FF] rounded-3xl p-7 hover:shadow-md transition duration-350 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-[#F4922A] flex items-center justify-center mb-4 group-hover:scale-110 transition duration-200 shadow-md">
                        <i data-lucide="book-open" class="text-white w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mb-2">Akses Mudah</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Belajar langsung dari buku resmi, kapanpun, tanpa perlu cetak buku fisik.
                    </p>
                </div>

                
                <div class="bg-[#E5F8FF] rounded-3xl p-7 hover:shadow-md transition duration-350 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-[#F4922A] flex items-center justify-center mb-4 group-hover:scale-110 transition duration-200 shadow-md">
                        <i data-lucide="layers" class="text-white w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mb-2">Belajar Interaktif</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Ada quiz, flashcard, dan simulasi ujian untuk beneran paham.
                    </p>
                </div>

                
                <div class="bg-[#E5F8FF] rounded-3xl p-7 hover:shadow-md transition duration-350 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-[#F4922A] flex items-center justify-center mb-4 group-hover:scale-110 transition duration-200 shadow-md">
                        <i data-lucide="sparkles" class="text-white w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mb-2">Ringkasan AI</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Materi dilengkapi AI agar lebih singkat, jelas, dan mudah dipahami.
                    </p>
                </div>

                
                <div class="bg-[#E5F8FF] rounded-3xl p-7 hover:shadow-md transition duration-350 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-[#F4922A] flex items-center justify-center mb-4 group-hover:scale-110 transition duration-200 shadow-md">
                        <i data-lucide="graduation-cap" class="text-white w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mb-2">Berbasis Materi Resmi</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Soal, kuis, dan ringkasan diambil dari buku tematik sesuai kurikulum.
                    </p>
                </div>
            </div>
        </div>
    </section>

    
    <section class="bg-[#E5F8FF] py-20 px-8">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-12">
                <h2 class="text-3xl lg:text-4xl font-extrabold text-slate-800 font-jakarta">
                    Nikmati Keragaman Fitur
                </h2>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-6">
                
                <div class="bg-white rounded-3xl p-7 shadow-sm border border-slate-100 hover:shadow-md transition duration-200 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-blue-50 text-[#1E3A5F] flex items-center justify-center mb-4 group-hover:scale-110 transition">
                        <i data-lucide="clipboard-list" class="w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mt-4 mb-2">Quiz</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Latihan soal bersumber langsung dari buku tematik pada setiap bab.
                    </p>
                </div>

                
                <div class="bg-white rounded-3xl p-7 shadow-sm border border-slate-100 hover:shadow-md transition duration-200 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-blue-50 text-[#1E3A5F] flex items-center justify-center mb-4 group-hover:scale-110 transition">
                        <i data-lucide="book-marked" class="w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mt-4 mb-2">Flashcard</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Istilah dan konsep penting dari materi buku tematik, dibuat kartu agar lebih mudah diingat.
                    </p>
                </div>

                
                <div class="bg-white rounded-3xl p-7 shadow-sm border border-slate-100 hover:shadow-md transition duration-200 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-blue-50 text-[#1E3A5F] flex items-center justify-center mb-4 group-hover:scale-110 transition">
                        <i data-lucide="notebook-pen" class="w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mt-4 mb-2">Notes AI</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Ringkasan materi dibuat dari konten buku tematik dengan bantuan AI.
                    </p>
                </div>

                
                <div class="bg-white rounded-3xl p-7 shadow-sm border border-slate-100 hover:shadow-md transition duration-200 flex flex-col group">
                    <div class="w-12 h-12 rounded-2xl bg-blue-50 text-[#1E3A5F] flex items-center justify-center mb-4 group-hover:scale-110 transition">
                        <i data-lucide="timer" class="w-6 h-6"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-800 mt-4 mb-2">Ujian Simulasi</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">
                        Latihan ujian bertipe multi bab, lengkap dengan batas waktu dan tipe soal.
                    </p>
                </div>
            </div>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-8 my-12">
        <div class="bg-[#1E3A5F] rounded-[2rem] py-14 px-12 flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden shadow-2xl">
            <div class="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-blue-700/20 blur-2xl pointer-events-none"></div>

            <div class="space-y-2 text-center lg:text-left relative z-10">
                <h2 class="text-3xl font-extrabold text-white leading-tight">
                    Siap Belajar Lebih Terarah?
                </h2>
                <p class="text-blue-200 text-base">
                    Bergabung sekarang dan mulai perjalanan belajarmu dari buku resmi.
                </p>
            </div>

            <div class="relative z-10 flex-shrink-0">
                <a href="<?php echo e(route('register')); ?>" class="bg-[#F4922A] hover:bg-orange-600 text-white rounded-2xl px-8 py-4 font-bold text-base hover:scale-105 transition duration-200 block text-center shadow-lg shadow-orange-500/20">
                    Daftar Sekarang →
                </a>
            </div>
        </div>
    </section>

    
    <footer class="bg-[#1E3A5F] py-16 px-12">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">

            
            <div>
                <img src="<?php echo e(asset('images/logo_2.png')); ?>" class="h-9 mb-4" alt="SahabatBuku Logo">
                <p class="text-[#F4922A] text-xl font-semibold mt-1">Belajar di mana pun, kapanpun!</p>
                <hr class="border-slate-500 my-6 w-48">
                <nav class="flex flex-wrap gap-6">
                    <a href="#" class="text-[#F4922A] text-base font-medium hover:text-orange-300 transition">About</a>
                    <a href="#" class="text-[#F4922A] text-base font-medium hover:text-orange-300 transition">Menu</a>
                    <a href="#" class="text-[#F4922A] text-base font-medium hover:text-orange-300 transition">Services</a>
                    <a href="#" class="text-[#F4922A] text-base font-medium hover:text-orange-300 transition">FAQ</a>
                    <a href="#" class="text-[#F4922A] text-base font-medium hover:text-orange-300 transition">Support</a>
                </nav>
            </div>

            
            <div class="bg-white rounded-2xl overflow-hidden shadow-lg">
                
                <div class="bg-[#F4922A] px-6 py-3 flex items-center gap-2">
                    <i data-lucide="bookmark" class="w-4 h-4 text-white flex-shrink-0"></i>
                    <p class="text-white text-sm font-semibold">Beri saran agar kami semakin berkembang!</p>
                </div>
                
                <div class="bg-white px-6 py-6">
                    <p class="text-slate-800 font-bold text-base mb-4">Kirimkan saran lewat sini!</p>
                    <?php if(session('saran_success')): ?>
                        <div class="bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-4 py-3 mb-4">
                            <?php echo e(session('saran_success')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('saran.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="flex gap-3">
                            <input
                                type="text" name="isi" required
                                placeholder="Kirimkan saran lewat sini!"
                                class="flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:border-[#F4922A] transition font-jakarta"
                            >
                            <button
                                type="submit" id="saran-btn"
                                class="bg-[#F4922A] text-white rounded-xl px-6 py-2.5 text-sm font-bold hover:bg-orange-600 transition flex-shrink-0 min-w-[90px]"
                            >
                                Submit
                            </button>
                        </div>
                        <?php $__errorArgs = ['isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-xs text-red-400"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>
                </div>
            </div>

        </div>
    </footer>

    
    <div class="bg-white border-t border-slate-100 py-4 text-center">
        <p class="text-slate-500 text-sm">© 2026 SahabatBuku</p>
    </div>

    
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    </script>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/TextPlugin.min.js"></script>
    <script>
    gsap.registerPlugin(TextPlugin);

    const saranBtn = document.getElementById('saran-btn');
    const saranForm = saranBtn ? saranBtn.closest('form') : null;

    if (saranBtn && saranForm) {
        const btnTL = gsap.timeline({ paused: true })
            .to(saranBtn, {
                duration: 0.8,
                text: { value: 'Mengirim...', type: 'diff' },
                ease: 'sine.in'
            })
            .to(saranBtn, {
                duration: 0.4,
                text: { value: 'Mengirim', type: 'diff' },
                ease: 'sine.inOut',
                repeat: 3,
                yoyo: true
            })
            .to(saranBtn, {
                text: 'Terkirim! 🙏',
                ease: 'none',
                onComplete: () => {
                    saranBtn.disabled = false;
                    saranForm.submit();
                }
            }, '+=0.3');

        saranForm.addEventListener('submit', function(e) {
            const input = saranForm.querySelector('input[name="isi"]');
            if (!input || !input.value.trim()) return; // let HTML validation handle it

            e.preventDefault(); // stop native submit
            saranBtn.disabled = true;
            btnTL.play(0);
        });
    }
    </script>
</body>
</html><?php /**PATH C:\laragon\www\MyProject\resources\views/welcome.blade.php ENDPATH**/ ?>