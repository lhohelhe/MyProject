
<style>
    .sidebar-glass {
        background: rgba(255,255,255,0.15);
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
    }
</style>

<aside class="sidebar-glass w-[280px] h-screen sticky top-0 flex flex-col py-12 px-7 flex-shrink-0 overflow-y-auto">

    
    <img src="<?php echo e(asset('images/logo_1.png')); ?>" alt="SahabatBuku" class="h-10">

    
    <?php
        use App\Services\XpService;
        $user = Auth::user();
        $currentLevel = $user->level;
        $progress = XpService::getProgressToNextLevel($user);
        $currentXp = XpService::getXpInCurrentLevel($user);
        $xpForNext = XpService::getXpForNextLevel($user);
    ?>
    <div class="p-4 mt-8 text-white rounded-lg bg-gradient-to-r from-orange-400 to-orange-500">
        <div class="flex items-center justify-between mb-3">
            <div>
                <div class="text-sm font-medium opacity-90">Level</div>
                <div class="text-2xl font-bold"><?php echo e($currentLevel); ?></div>
            </div>
            <div class="text-right">
                <div class="text-sm font-medium opacity-90">XP</div>
                <div class="text-lg font-bold"><?php echo e($user->total_xp); ?></div>
            </div>
        </div>

        
        <div class="mb-2">
            <div class="w-full h-2 rounded-full bg-white/30">
                <div class="h-2 transition-all duration-300 bg-white rounded-full" style="width: <?php echo e($progress); ?>%"></div>
            </div>
        </div>
        <div class="text-xs opacity-90"><?php echo e($currentXp); ?> / <?php echo e($xpForNext); ?> XP</div>
    </div>

    
    <nav class="flex flex-col flex-1 gap-10 mt-10">

        
        <a href="<?php echo e(route('user.katalog')); ?>" class="flex items-center gap-5 group">
            <svg width="22" height="23" viewBox="0 0 22 23" fill="none">
                <path d="M2.89474 17.7727C2.127 17.7727 1.39072 18.0481 0.847849 18.5382C0.30498 19.0284 0 19.6932 0 20.3864M0 20.3864C0 21.0795 0.30498 21.7443 0.847849 22.2345C1.39072 22.7246 2.127 23 2.89474 23H22M0 20.3864V2.61364C0 1.92046 0.30498 1.25567 0.847849 0.765516C1.39072 0.275364 2.127 0 2.89474 0H20.8421L20.6667 17.78H2.88547M20.2632 17.7727C19.4954 17.7727 18.7591 18.0481 18.2163 18.5382C17.6734 19.0284 17.3684 19.6932 17.3684 20.3864C17.3684 21.0795 17.6734 21.7443 18.2163 22.2345C18.7591 22.7246 19.4954 23 20.2632 23" stroke="black" stroke-width="2"/>
            </svg>
            <span class="text-[26px] font-medium <?php echo e(request()->routeIs('user.katalog') ? 'text-blue-600 font-bold' : 'text-black'); ?>">Katalog</span>
        </a>

        
        <div>
            <div class="flex items-center gap-5 mb-3">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <path d="M1.22222 9.77778H8.55556C8.87971 9.77778 9.19059 9.64901 9.4198 9.4198C9.64901 9.19059 9.77778 8.87971 9.77778 8.55556V1.22222C9.77778 0.898069 9.64901 0.587192 9.4198 0.357981C9.19059 0.128769 8.87971 0 8.55556 0H1.22222C0.898069 0 0.587192 0.128769 0.357981 0.357981C0.128769 0.587192 0 0.898069 0 1.22222V8.55556C0 8.87971 0.128769 9.19059 0.357981 9.4198C0.587192 9.64901 0.898069 9.77778 1.22222 9.77778ZM13.4444 9.77778H20.7778C21.1019 9.77778 21.4128 9.64901 21.642 9.4198C21.8712 9.19059 22 8.87971 22 8.55556V1.22222C22 0.898069 21.8712 0.587192 21.642 0.357981C21.4128 0.128769 21.1019 0 20.7778 0H13.4444C13.1203 0 12.8094 0.128769 12.5802 0.357981C12.351 0.587192 12.2222 0.898069 12.2222 1.22222V8.55556C12.2222 8.87971 12.351 9.19059 12.5802 9.4198C12.8094 9.64901 13.1203 9.77778 13.4444 9.77778ZM1.22222 22H8.55556C8.87971 22 9.19059 21.8712 9.4198 21.642C9.64901 21.4128 9.77778 21.1019 9.77778 20.7778V13.4444C9.77778 13.1203 9.64901 12.8094 9.4198 12.5802C9.19059 12.351 8.87971 12.2222 8.55556 12.2222H1.22222C0.898069 12.2222 0.587192 12.351 0.357981 12.5802C0.128769 12.8094 0 13.1203 0 13.4444V20.7778C0 21.1019 0.128769 21.4128 0.357981 21.642C0.587192 21.8712 0.898069 22 1.22222 22ZM17.1111 22C19.8073 22 22 19.8073 22 17.1111C22 14.4149 19.8073 12.2222 17.1111 12.2222C14.4149 12.2222 12.2222 14.4149 12.2222 17.1111C12.2222 19.8073 14.4149 22 17.1111 22Z" fill="black"/>
                </svg>
                <span class="text-[24px] font-medium text-black">Kategori</span>
            </div>
            <div class="flex gap-5 pl-1">
                <div class="w-[3px] rounded-full bg-[#9E9E9E]"></div>
                <div class="flex flex-col flex-1 gap-8">
                    <?php $kategori = \App\Models\KategoriMapel::all(); ?>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('user.katalog', ['kategori' => $k->id_kategori])); ?>" class="text-[18px] font-medium text-black hover:text-blue-600">
                            <?php echo e($k->nama_kategori); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </nav>

    
    <div class="flex flex-col gap-8 mt-auto">
        <a href="<?php echo e(route('user.profile')); ?>" class="flex items-center gap-5">
            <svg width="22" height="27" viewBox="0 0 22 27" fill="none">
                <path d="M11 12.8571C11.8334 12.8571 12.6586 12.6909 13.4286 12.3678C14.1985 12.0447 14.8981 11.5712 15.4874 10.9743C16.0767 10.3773 16.5442 9.66863 16.8631 8.88868C17.182 8.10873 17.3462 7.27278 17.3462 6.42857C17.3462 5.58436 17.182 4.74841 16.8631 3.96846C16.5442 3.18851 16.0767 2.47983 15.4874 1.88288C14.8981 1.28594 14.1985 0.812412 13.4286 0.489346C12.6586 0.16628 11.8334 0 11 0C10.1666 0 9.34138 0.16628 8.57143 0.489346C7.80148 0.812412 7.10189 1.28594 6.51259 1.88288C5.9233 2.47983 5.45584 3.18851 5.13692 3.96846C4.81799 4.74841 4.65385 5.58436 4.65385 6.42857C4.65385 7.27278 4.81799 8.10873 5.13692 8.88868C5.45584 9.66863 5.9233 10.3773 6.51259 10.9743C7.10189 11.5712 7.80148 12.0447 8.57143 12.3678C9.34138 12.6909 10.1666 12.8571 11 12.8571ZM9.42933 15.8571C4.22019 15.8571 0 20.1321 0 25.4089C0 26.2875 0.703365 27 1.57067 27H20.4293C21.2966 27 22 26.2875 22 25.4089C22 20.1321 17.7798 15.8571 12.5707 15.8571H9.42933Z" fill="black"/>
            </svg>
            <span class="text-[24px] font-medium <?php echo e(request()->routeIs('user.profile') ? 'text-blue-600 font-bold' : 'text-black'); ?>">Profil</span>
        </a>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="flex items-center gap-5">
                <svg width="22" height="30" viewBox="0 0 22 30" fill="none">
                    <path d="M10.1563 0C10.5453 0 10.9305 0.0754386 11.2899 0.222008C11.6493 0.368578 11.9758 0.583409 12.2509 0.854235C12.526 1.12506 12.7442 1.44658 12.8931 1.80043C13.0419 2.15428 13.1185 2.53354 13.1185 2.91654C13.1185 3.29955 13.0419 3.6788 12.8931 4.03265C12.7442 4.3865 12.526 4.70802 12.2509 4.97885C11.9758 5.24967 11.6493 5.4645 11.2899 5.61107C10.9305 5.75764 10.5453 5.83308 10.1563 5.83308C9.76728 5.83308 9.38208 5.75764 9.02268 5.61107C8.66329 5.4645 8.33673 5.24967 8.06166 4.97885C7.78659 4.70802 7.56839 4.3865 7.41952 4.03265C7.27066 3.6788 7.19404 3.29955 7.19404 2.91654C7.19404 2.53354 7.27066 2.15428 7.41952 1.80043C7.56839 1.44658 7.78659 1.12506 8.06166 0.854235C8.33673 0.583409 8.66329 0.368578 9.02268 0.222008C9.38208 0.0754386 9.76728 0 10.1563 0ZM6.77086 10.7079C6.77086 8.93711 8.23082 7.49968 10.0293 7.49968C11.1032 7.49968 12.1294 7.92153 12.8858 8.66629L15.4354 11.1766C15.7528 11.4891 16.1813 11.6662 16.6309 11.6662H18.6146C18.9214 11.6662 19.2123 11.7495 19.4609 11.8901V7.91632C19.4609 7.22365 20.0269 6.66638 20.7305 6.66638C21.434 6.66638 22 7.22365 22 7.91632V28.7488C22 29.4414 21.434 29.9987 20.7305 29.9987C20.0269 29.9987 19.4609 29.4414 19.4609 28.7488V14.7754C19.2123 14.916 18.9214 14.9994 18.6146 14.9994H16.6309C15.282 14.9994 13.9913 14.4733 13.0392 13.5359L12.6901 13.1921V18.8794L14.515 20.421C15.4513 21.2126 16.0649 22.3063 16.2395 23.5094L16.906 28.0977C17.0382 29.0092 16.3929 29.8529 15.4672 29.9831C14.5415 30.1133 13.6845 29.4779 13.5523 28.5665L12.8858 23.9781C12.8276 23.5771 12.6213 23.2125 12.3092 22.9469L8.53234 19.7596C7.40563 18.8117 6.76028 17.4211 6.76028 15.9629V10.7027L6.77086 10.7079Z" fill="#FF0000"/>
                </svg>
                <span class="text-[24px] font-medium text-[#FF0000]">Keluar</span>
            </button>
        </form>
    </div>

</aside>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    lucide.createIcons();
</script><?php /**PATH C:\xampp\htdocs\MyProject\resources\views/components/user-sidebar.blade.php ENDPATH**/ ?>