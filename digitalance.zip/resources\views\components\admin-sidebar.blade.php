<!-- Sidebar -->
<aside class="flex-shrink-0 w-full lg:w-56 lg:h-screen lg:sticky lg:top-0 bg-[#1E293B] overflow-y-auto">
    <!-- Logo -->
    <div class="px-6 pt-6 pb-8">
        <img src="{{ asset('images/logo_2.png') }}" alt="SahabatBuku Logo" class="h-8"/>
    </div>
    
    <nav class="px-4 space-y-1">
        {{-- dashboard --}}
        <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.dashboard') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span>Dashboard</span>
        </a>

        {{-- data user --}}
        <a href="{{ route('dashboard-user.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('dashboard-user.*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span>Data User</span>
        </a>

        {{-- data buku --}}
        <a href="{{ route('dashboard-buku.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ (request()->routeIs('dashboard-buku.*') && (!request()->has('active_menu') || request()->input('active_menu') === 'buku')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="book-open" class="w-5 h-5"></i>
            <span>Data Buku</span>
        </a>

        {{-- kelola bab --}}
        <a href="{{ route('dashboard-buku.index', ['active_menu' => 'bab']) }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ (request()->input('active_menu') === 'bab' || (request()->routeIs('bab.*') && request()->input('active_menu', 'bab') === 'bab')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="layers" class="w-5 h-5"></i>
            <span>Kelola Bab</span>
        </a>

        {{-- kelola subbab --}}
        <a href="{{ route('dashboard-buku.index', ['active_menu' => 'subab']) }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ (request()->input('active_menu') === 'subab' || (request()->routeIs('subab.*') && request()->input('active_menu') === 'subab') || (request()->routeIs('bab.*') && request()->input('active_menu') === 'subab')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="book-marked" class="w-5 h-5"></i>
            <span>Kelola Subbab</span>
        </a>

        {{-- kelola materi --}}
        <a href="{{ route('dashboard-buku.index', ['active_menu' => 'materi']) }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ (request()->input('active_menu') === 'materi' || (request()->routeIs('materi.*') && request()->input('active_menu') === 'materi') || (request()->routeIs('bab.*') && request()->input('active_menu') === 'materi')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="file-text" class="w-5 h-5"></i>
            <span>Kelola Materi</span>
        </a>

        {{-- simulasi ujian --}}
        <a href="{{ route('simulasi.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('simulasi.*') || request()->routeIs('soal-simulasi.*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="graduation-cap" class="w-5 h-5"></i>
            <span>Simulasi Ujian</span>
        </a>

        {{-- quiz --}}
        <a href="/admin/quiz" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->is('admin/quiz*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
            <i data-lucide="clipboard-list" class="w-5 h-5"></i>
            <span>Data Quiz</span>
        </a>

        <a href="{{ route('admin.saran.index') }}"
           class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white text-sm font-medium transition-all {{ request()->routeIs('admin.saran.*') ? 'bg-white/15 text-white' : '' }}">
            <i data-lucide="message-square" class="w-4 h-4"></i>
            Saran
            @php $unread = \App\Models\Saran::where('status','belum_dibaca')->count(); @endphp
            @if($unread > 0)
                <span class="ml-auto bg-[#F4922A] text-white text-xs font-bold px-2 py-0.5 rounded-full">{{ $unread }}</span>
            @endif
        </a>
    </nav>
</aside>

<script>
    if (typeof lucide !== 'undefined') lucide.createIcons();
</script>