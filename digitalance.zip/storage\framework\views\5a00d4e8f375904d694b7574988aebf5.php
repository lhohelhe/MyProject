

<?php $__env->startSection('title', 'Dashboard Admin - SahabatBuku'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="text-2xl font-bold text-slate-800 mb-6 font-jakarta">
            Dashboard Admin
        </h1>

        
        <?php if(session('success')): ?>
        <div class="px-4 py-3 mb-6 text-green-800 bg-green-100 rounded-xl font-jakarta">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="users" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">User</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e(\App\Models\User::where('role', 'user')->count()); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="shield-check" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Admin</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e(\App\Models\User::where('role', 'admin')->count()); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="book-open" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Mapel</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e($total_kategori); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="book" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Buku</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e($total_buku); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="layers" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Bab</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e($total_bab); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="book-marked" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Subbab</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e(\App\Models\Subab::count()); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="file-text" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Materi</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e(\App\Models\Materi::count()); ?></p>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-11 h-11 rounded-xl flex items-center justify-center bg-orange-50 text-[#F4922A]">
                    <i data-lucide="clipboard-list" class="w-5 h-5"></i>
                </div>
                <div>
                    <p class="text-xs text-slate-500 font-medium font-jakarta">Quiz</p>
                    <p class="text-2xl font-bold text-slate-800 font-jakarta"><?php echo e(\App\Models\Quiz::count()); ?></p>
                </div>
            </div>

        </div>

        
        <div class="p-6 bg-white shadow-sm border border-slate-100 rounded-2xl">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold font-jakarta text-slate-800">Buku Terbaru Ditambahkan</h2>
                <a href="<?php echo e(route('dashboard-buku.index')); ?>"
                   class="flex items-center gap-1 text-sm text-slate-400 font-jakarta hover:text-[#F4922A] transition-colors">
                    Lihat lainnya <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $buku_terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center gap-4 py-3 border-b last:border-b-0 border-slate-100">

                
                <?php if($buku->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $buku->gambar)); ?>"
                         class="object-cover w-12 h-16 rounded-lg"
                         alt="<?php echo e($buku->judul_buku); ?>">
                <?php else: ?>
                    <div class="flex items-center justify-center w-12 h-16 bg-gray-100 rounded-lg">
                        <i data-lucide="book-open" class="w-6 h-6 text-gray-400"></i>
                    </div>
                <?php endif; ?>

                
                <div class="flex-1">
                    <p class="font-semibold font-jakarta text-slate-800 text-sm"><?php echo e($buku->judul_buku); ?></p>
                    <p class="text-xs text-slate-500 font-jakarta">
                        <?php echo e($buku->kategori->nama_kategori ?? '-'); ?> · kelas <?php echo e($buku->kelas); ?> · semester <?php echo e($buku->semester); ?>

                    </p>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-400 font-jakarta">belum ada buku yang ditambahkan.</p>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MyProject\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>