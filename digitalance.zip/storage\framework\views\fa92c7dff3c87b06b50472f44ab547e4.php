<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-[#F5F5F5]">
<div class="flex flex-col min-h-screen lg:flex-row">
    <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
    <main class="flex-1 p-4 sm:p-6 lg:p-16">

        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10">
            dashboard admin
        </h1>

        
        <?php if(session('success')): ?>
        <div class="px-4 py-3 mb-6 text-green-800 bg-green-100 rounded-xl font-jakarta">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        
        <div class="grid grid-cols-2 gap-4 mb-10 lg:grid-cols-4">

            <div class="p-6 bg-white shadow-md rounded-xl">
                <p class="mb-1 text-sm text-gray-500 font-jakarta">total buku</p>
                <p class="text-4xl font-extrabold font-jakarta"><?php echo e($total_buku); ?></p>
            </div>

            <div class="p-6 bg-white shadow-md rounded-xl">
                <p class="mb-1 text-sm text-gray-500 font-jakarta">total pengguna</p>
                <p class="text-4xl font-extrabold font-jakarta"><?php echo e($total_user); ?></p>
            </div>

            <div class="p-6 bg-white shadow-md rounded-xl">
                <p class="mb-1 text-sm text-gray-500 font-jakarta">total kategori</p>
                <p class="text-4xl font-extrabold font-jakarta"><?php echo e($total_kategori); ?></p>
            </div>

            <div class="p-6 bg-white shadow-md rounded-xl">
                <p class="mb-1 text-sm text-gray-500 font-jakarta">total bab</p>
                <p class="text-4xl font-extrabold font-jakarta"><?php echo e($total_bab); ?></p>
            </div>

        </div>

        
        <div class="p-6 bg-white shadow-md rounded-xl">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold font-jakarta">buku terbaru ditambahkan</h2>
                <a href="<?php echo e(route('dashboard-buku.index')); ?>"
                   class="text-sm text-gray-400 font-jakarta hover:text-black">
                    lihat lainnya →
                </a>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $buku_terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center gap-4 py-3 border-b last:border-b-0">

                
                <?php if($buku->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $buku->gambar)); ?>"
                         class="object-cover w-12 h-16 rounded-lg"
                         alt="<?php echo e($buku->judul_buku); ?>">
                <?php else: ?>
                    <div class="flex items-center justify-center w-12 h-16 text-2xl bg-gray-100 rounded-lg">
                        📖
                    </div>
                <?php endif; ?>

                
                <div class="flex-1">
                    <p class="font-semibold font-jakarta"><?php echo e($buku->judul_buku); ?></p>
                    <p class="text-sm text-gray-500 font-jakarta">
                        <?php echo e($buku->kategori->nama_kategori ?? '-'); ?> · kelas <?php echo e($buku->kelas); ?> · semester <?php echo e($buku->semester); ?>

                    </p>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-400 font-jakarta">belum ada buku yang ditambahkan.</p>
            <?php endif; ?>
        </div>

    </main>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\MyProject\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>