<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($buku->judul_buku); ?> - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased font-jakarta" style="background-color: #E5F8FF;">
<div class="flex min-h-screen">

    <?php if (isset($component)) { $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $attributes = $__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__attributesOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec)): ?>
<?php $component = $__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec; ?>
<?php unset($__componentOriginal3c6bd4b0d916bb05d283d1879f0e28ec); ?>
<?php endif; ?>

    
    <main class="flex-1 px-8 py-8 overflow-y-auto">

        <div class="p-6 mb-12 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)]">
            <div class="grid grid-cols-1 gap-8 md:grid-cols-3">
                
                <div class="flex justify-center md:justify-start">
                    <?php if($buku->gambar): ?>
                        <img src="<?php echo e(Storage::url($buku->gambar)); ?>" alt="<?php echo e($buku->judul_buku); ?>" class="object-cover shadow-md rounded-xl" style="height: 280px; width: 200px;">
                    <?php else: ?>
                        <div class="flex items-center justify-center w-48 bg-gray-200 h-72 rounded-xl">
                            <span class="text-sm text-gray-400 font-jakarta">Tidak ada cover</span>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="md:col-span-2">
                    
                    <h1 class="mb-4 text-2xl font-bold text-black font-jakarta"><?php echo e($buku->judul_buku); ?></h1>

                    
                    <div class="inline-block mb-6">
                        <span class="px-3 py-1 text-sm font-bold text-white rounded-lg font-jakarta" style="background-color: #F0924E;">
                            Kelas <?php echo e($buku->kelas); ?>

                        </span>
                    </div>

                    
                    <div class="mb-6 border-t border-gray-200"></div>

                    
                    <div class="grid grid-cols-2 gap-4 sm:grid-cols-4">
                        <div>
                            <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Penerbit</p>
                            <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($buku->penerbit ?? 'Tidak tersedia'); ?></p>
                        </div>
                        <div>
                            <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">ISBN</p>
                            <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($buku->isbn ?? 'Tidak tersedia'); ?></p>
                        </div>
                        <div>
                            <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Edisi</p>
                            <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($buku->edisi ?? 'Tidak tersedia'); ?></p>
                        </div>
                        <div>
                            <p class="mb-2 text-xs font-semibold text-gray-600 font-jakarta">Penulis</p>
                            <p class="text-sm font-bold text-gray-800 font-jakarta"><?php echo e($buku->penulis ?? 'Tidak tersedia'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="mb-12">
            <div class="flex items-center gap-3 p-4 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)]">
                
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor" class="text-blue-500">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                </svg>
                
                <span class="font-semibold text-gray-800 font-jakarta">
                    <?php if($progress == 0): ?>
                        Belum ada progres, mari mulai!
                    <?php else: ?>
                        Progres: <?php echo e($progress); ?>%
                    <?php endif; ?>
                </span>
            </div>
        </div>

        
        <div class="mb-12">
            <h2 class="mb-6 text-lg font-bold text-black font-jakarta">Fitur Belajar</h2>
            <div class="grid grid-cols-2 gap-4 md:grid-cols-4">
                
                <a href="#" class="p-6 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] hover:shadow-lg transition text-center">
                    <div class="mb-4 text-orange-500">
                        <i data-lucide="notebook-pen" class="w-10 h-10 mx-auto"></i>
                    </div>
                    <p class="mb-3 text-sm font-bold text-gray-800 font-jakarta">Notes AI</p>
                    <div class="flex justify-center gap-1">
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                    </div>
                </a>

                
                <a href="<?php echo e(route('user.quiz.index', $buku->bab->first()?->id_bab ?? '#')); ?>" class="p-6 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] hover:shadow-lg transition text-center">
                    <div class="mb-4 text-blue-500">
                        <i data-lucide="circle-help" class="w-10 h-10 mx-auto"></i>
                    </div>
                    <p class="mb-3 text-sm font-bold text-gray-800 font-jakarta">Quiz</p>
                    <div class="flex justify-center gap-1">
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                    </div>
                </a>

                
                <a href="<?php echo e(route('user.flashcard', $buku->bab->first()?->subbab->first()?->id_subbab ?? '#')); ?>" class="p-6 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] hover:shadow-lg transition text-center">
                    <div class="mb-4 text-purple-500">
                        <i data-lucide="gallery-vertical-end" class="w-10 h-10 mx-auto"></i>
                    </div>
                    <p class="mb-3 text-sm font-bold text-gray-800 font-jakarta">Flashcard</p>
                    <div class="flex justify-center gap-1">
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                    </div>
                </a>

                
                <a href="<?php echo e(route('user.simulasi.index', ['book' => $buku->id_buku])); ?>" class="p-6 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] hover:shadow-lg transition text-center">
                    <div class="mb-4 text-green-500">
                        <i data-lucide="clipboard" class="w-10 h-10 mx-auto"></i>
                    </div>
                    <p class="mb-3 text-sm font-bold text-gray-800 font-jakarta">Ujian Simulasi</p>
                    <div class="flex justify-center gap-1">
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                        <i data-lucide="star" class="w-5 h-5 text-gray-300"></i>
                    </div>
                </a>
            </div>
        </div>

        
        <div>
            <div class="flex items-center gap-2 mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" class="text-blue-500">
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                </svg>
                <h2 class="text-lg font-bold text-black font-jakarta">Daftar Isi</h2>
            </div>

            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <?php $__empty_1 = true; $__currentLoopData = $buku->bab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-6 bg-white rounded-2xl shadow-[0px_3px_10px_0px_rgba(0,0,0,0.15)] relative overflow-hidden">
                        
                        <div class="absolute top-0 left-0 px-3 py-1 font-bold text-white rounded-br-lg font-jakarta" style="background-color: #F0924E;">
                            BAB <?php echo e($index + 1); ?>

                        </div>

                        
                        <div class="pt-8">
                            <p class="mb-4 text-sm font-bold text-gray-600 uppercase font-jakarta"><?php echo e($bab->judul_bab); ?></p>
                            <ul class="space-y-2">
                                <?php $__empty_2 = true; $__currentLoopData = $bab->subbab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subbab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <?php $__empty_3 = true; $__currentLoopData = $subbab->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                        <li>
                                            <a href="<?php echo e(route('user.materi.show', $materi->id_materi)); ?>" class="text-sm text-gray-700 hover:text-[#F0924E] transition font-jakarta">
                                                • <?php echo e($materi->judul_materi ?? 'Materi'); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                        <li class="text-sm text-gray-400 font-jakarta">Tidak ada materi</li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <li class="text-sm text-gray-400 font-jakarta">Tidak ada sub-bab</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-6 text-center bg-white col-span-full rounded-2xl">
                        <p class="text-gray-400 font-jakarta">Belum ada bab</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </main>

</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/user/buku.blade.php ENDPATH**/ ?>