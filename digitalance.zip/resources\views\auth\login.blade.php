<!DOCTYPE html> 
<html lang="id"> 
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SahabatBuku</title> 
    @vite(['resources/css/app.css', 'resources/js/app.js']) 
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head> 
<body class="min-h-screen bg-slate-50">
    <div class="flex min-h-screen">
        <!-- Left Column (Form) -->
        <div class="flex flex-col justify-center w-full px-6 py-12 lg:w-1/2 bg-white sm:px-12">
            <div class="w-full max-w-sm mx-auto">
                <!-- Logo -->
                <img src="{{ asset('images/logo_1.png') }}" alt="SahabatBuku Logo" class="h-8 mb-8">
                
                <!-- Header -->
                <h2 class="text-2xl font-bold text-slate-800 mb-1">Selamat Datang 👋</h2>
                <p class="text-sm text-slate-500 mb-6">Masuk ke akun SahabatBuku kamu</p>
                
                <!-- Form -->
                <form method="POST" action="{{ route('login') }}" class="space-y-5">
                    @csrf
                    
                    <!-- Email -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Email</label>
                        <div class="relative flex items-center">
                            <i data-lucide="mail" class="absolute left-0 w-4 h-4 text-slate-400"></i>
                            <input type="email" name="email" value="{{ old('email') }}" required placeholder="email@sekolah.sch.id" class="w-full bg-transparent border-0 border-b-2 border-slate-200 focus:border-[#F4922A] focus:ring-0 py-2 pl-8 text-sm text-slate-800 placeholder-slate-400 transition-colors">
                        </div>
                        @error('email')
                            <p class="mt-2 text-xs text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                    
                    <!-- Password -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Password</label>
                        <div class="relative flex items-center">
                            <i data-lucide="lock" class="absolute left-0 w-4 h-4 text-slate-400"></i>
                            <input type="password" name="password" required placeholder="••••••••" class="w-full bg-transparent border-0 border-b-2 border-slate-200 focus:border-[#F4922A] focus:ring-0 py-2 pl-8 text-sm text-slate-800 placeholder-slate-400 transition-colors">
                        </div>
                        @error('password')
                            <p class="mt-2 text-xs text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                    
                    <!-- Remember & Forgot -->
                    <div class="flex items-center justify-between text-xs text-slate-600">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="remember" class="rounded text-[#F4922A] focus:ring-[#F4922A] border-slate-300">
                            <span>Ingat saya</span>
                        </label>
                        <a href="{{ route('password.request') }}" class="text-[#F4922A] hover:underline font-medium">
                            Lupa password?
                        </a>
                    </div>
                    
                    <!-- Submit -->
                    <button type="submit" class="w-full bg-[#F4922A] text-white rounded-xl py-3 font-semibold hover:bg-[#e08420] transition-colors text-sm shadow-sm mt-4">
                        Masuk
                    </button>
                    
                    <!-- Register Link -->
                    <p class="text-xs text-center text-slate-600 mt-6">
                        Belum punya akun?
                        <a href="{{ route('register') }}" class="text-[#F4922A] font-semibold hover:underline">
                            Daftar
                        </a>
                    </p>
                </form>
            </div>
        </div>
        
        <!-- Right Column (Illustration) -->
        <div class="hidden lg:flex lg:w-1/2 bg-[#1E293B] rounded-l-[3rem] flex-col justify-center items-center p-12">
            <div class="max-w-md w-full flex flex-col items-center">
                <img src="{{ asset('images/Mobile login-rafiki 1.png') }}" alt="Login Illustration" class="w-4/5 h-auto drop-shadow-xl">
                <h3 class="text-white text-2xl font-bold text-center leading-snug whitespace-pre-line mt-8">
                    Belajar lebih terarah,
                    bersama SahabatBuku
                </h3>
            </div>
        </div>
    </div>
    
    <script>
        if (typeof lucide !== 'undefined') lucide.createIcons();
    </script>
</body> 
</html>