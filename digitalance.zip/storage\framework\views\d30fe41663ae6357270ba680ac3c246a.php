<!-- Sidebar -->
<aside class="flex-shrink-0 w-full lg:w-56 lg:h-screen lg:sticky lg:top-0 bg-[#1E293B] overflow-y-auto">
    <!-- Logo -->
    <div class="px-6 pt-6 pb-8">
        <img src="<?php echo e(asset('images/logo_2.png')); ?>" alt="SahabatBuku Logo" class="h-8"/>
    </div>
    
    <nav class="px-4 space-y-1">
        
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
            <span>Dashboard</span>
        </a>

        
        <a href="<?php echo e(route('dashboard-user.index')); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e(request()->routeIs('dashboard-user.*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="users" class="w-5 h-5"></i>
            <span>Data User</span>
        </a>

        
        <a href="<?php echo e(route('dashboard-buku.index')); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e((request()->routeIs('dashboard-buku.*') && (!request()->has('active_menu') || request()->input('active_menu') === 'buku')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="book-open" class="w-5 h-5"></i>
            <span>Data Buku</span>
        </a>

        
        <a href="<?php echo e(route('dashboard-buku.index', ['active_menu' => 'bab'])); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e((request()->input('active_menu') === 'bab' || (request()->routeIs('bab.*') && request()->input('active_menu', 'bab') === 'bab')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="layers" class="w-5 h-5"></i>
            <span>Kelola Bab</span>
        </a>

        
        <a href="<?php echo e(route('dashboard-buku.index', ['active_menu' => 'subab'])); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e((request()->input('active_menu') === 'subab' || (request()->routeIs('subab.*') && request()->input('active_menu') === 'subab') || (request()->routeIs('bab.*') && request()->input('active_menu') === 'subab')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="book-marked" class="w-5 h-5"></i>
            <span>Kelola Subbab</span>
        </a>

        
        <a href="<?php echo e(route('dashboard-buku.index', ['active_menu' => 'materi'])); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e((request()->input('active_menu') === 'materi' || (request()->routeIs('materi.*') && request()->input('active_menu') === 'materi') || (request()->routeIs('bab.*') && request()->input('active_menu') === 'materi')) ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="file-text" class="w-5 h-5"></i>
            <span>Kelola Materi</span>
        </a>

        
        <a href="<?php echo e(route('simulasi.index')); ?>" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e(request()->routeIs('simulasi.*') || request()->routeIs('soal-simulasi.*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="graduation-cap" class="w-5 h-5"></i>
            <span>Simulasi Ujian</span>
        </a>

        
        <a href="/admin/quiz" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all <?php echo e(request()->is('admin/quiz*') ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
            <i data-lucide="clipboard-list" class="w-5 h-5"></i>
            <span>Data Quiz</span>
        </a>

        <a href="<?php echo e(route('admin.saran.index')); ?>"
           class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-slate-300 hover:bg-white/10 hover:text-white text-sm font-medium transition-all <?php echo e(request()->routeIs('admin.saran.*') ? 'bg-white/15 text-white' : ''); ?>">
            <i data-lucide="message-square" class="w-4 h-4"></i>
            Saran
            <?php $unread = \App\Models\Saran::where('status','belum_dibaca')->count(); ?>
            <?php if($unread > 0): ?>
                <span class="ml-auto bg-[#F4922A] text-white text-xs font-bold px-2 py-0.5 rounded-full"><?php echo e($unread); ?></span>
            <?php endif; ?>
        </a>
    </nav>
</aside>

<script>
    if (typeof lucide !== 'undefined') lucide.createIcons();
</script><?php /**PATH C:\laragon\www\MyProject\resources\views/components/admin-sidebar.blade.php ENDPATH**/ ?>