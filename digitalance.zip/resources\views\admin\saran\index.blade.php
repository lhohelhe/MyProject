<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Saran - SahabatBuku</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-[#F8FAFC] antialiased">
    <div class="flex min-h-screen">
        <x-admin-sidebar />

        <main class="flex-1 p-8 overflow-y-auto">
            @if(session('success'))
                <div class="bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-4 py-3 mb-6">
                    {{ session('success') }}
                </div>
            @endif

            <div class="flex items-center justify-between mb-8">
                <div class="flex items-center gap-3">
                    <div class="p-2 bg-white rounded-xl shadow-sm border border-slate-100">
                        <i data-lucide="message-square" class="w-6 h-6 text-slate-600"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-slate-800 flex items-center gap-3">
                            Kelola Saran
                            @php $unread = \App\Models\Saran::where('status', 'belum_dibaca')->count(); @endphp
                            @if($unread > 0)
                                <span class="bg-orange-100 text-orange-600 text-xs font-semibold px-3 py-1 rounded-full">
                                    {{ $unread }} belum dibaca
                                </span>
                            @endif
                        </h1>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-100">
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">No.</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Saran</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-xs font-semibold text-slate-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse($sarans as $index => $saran)
                            <tr class="{{ $loop->even ? 'bg-slate-50/30' : 'bg-white' }} hover:bg-slate-50 transition-colors">
                                <td class="px-6 py-4 text-sm text-slate-500">
                                    {{ $sarans->firstItem() + $index }}
                                </td>
                                <td class="px-6 py-4">
                                    <p class="text-sm text-slate-700 max-w-md line-clamp-2" title="{{ $saran->isi }}">
                                        {{ $saran->isi }}
                                    </p>
                                </td>
                                <td class="px-6 py-4 text-xs text-slate-400">
                                    {{ $saran->created_at->format('d M Y H:i') }}
                                </td>
                                <td class="px-6 py-4">
                                    @if($saran->status === 'belum_dibaca')
                                        <span class="bg-orange-100 text-orange-600 text-xs font-semibold px-2 py-0.5 rounded-full">Belum Dibaca</span>
                                    @else
                                        <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-0.5 rounded-full">Sudah Dibaca</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4 flex gap-2">
                                    @if($saran->status === 'belum_dibaca')
                                        <form action="{{ route('admin.saran.read', $saran->id) }}" method="POST">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="bg-blue-50 text-blue-600 text-xs px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors">
                                                Tandai Dibaca
                                            </button>
                                        </form>
                                    @endif
                                    <form action="{{ route('admin.saran.destroy', $saran->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus saran ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="bg-red-50 text-red-500 text-xs px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="px-6 py-12 text-center">
                                    <div class="flex flex-col items-center justify-center space-y-3">
                                        <i data-lucide="inbox" class="w-12 h-12 text-slate-300"></i>
                                        <p class="text-slate-500 font-medium">Belum ada saran masuk</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
                @if($sarans->hasPages())
                    <div class="px-6 py-4 border-t border-slate-100">
                        {{ $sarans->links() }}
                    </div>
                @endif
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
