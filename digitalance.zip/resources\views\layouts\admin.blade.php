<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Admin - SahabatBuku')</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-[#F8FAFC]">
    <div class="flex flex-col min-h-screen lg:flex-row">
        <x-admin-sidebar />
        <main class="flex-1 p-4 sm:p-6 lg:p-10">
            @yield('content')
        </main>
    </div>
    <script>
        if (typeof lucide !== 'undefined') lucide.createIcons();
    </script>
    @stack('scripts')
</body>
</html>
