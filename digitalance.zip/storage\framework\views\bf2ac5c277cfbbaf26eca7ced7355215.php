<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Simulasi - SahabatBuku</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-[#F5F5F5]">
<div class="flex flex-col min-h-screen lg:flex-row">
    <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
    <main class="flex-1 p-4 sm:p-6 lg:p-16">
        <h1 class="mb-6 text-3xl font-extrabold sm:text-3xl lg:text-4xl font-jakarta lg:mb-10">
            Daftar Simulasi
        </h1>
        
        <!-- Header -->
        <div class="flex flex-col items-start justify-between gap-4 p-2 mb-6 bg-white shadow-md rounded-xl lg:p-2 lg:flex-row lg:items-center">
            <div class="text-2xl font-semibold lg:text-xl font-jakarta">
                Total Simulasi: <span class="ml-2"><?php echo e($simulasi->total()); ?></span>
            </div>
            <a href="<?php echo e(route('simulasi.create')); ?>" 
               class="flex items-center gap-3 px-4 py-3 text-xl font-bold text-black bg-admin-orange rounded-xl hover:bg-opacity-90 lg:text-xl font-jakarta">
                <span>Tambah Simulasi</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 lg:w-8 lg:h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 12h14"/>
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14"/>
                </svg>
            </a>
        </div>

        <!-- Header Tabel Desktop -->
        <div class="hidden p-4 mb-4 bg-white shadow-md lg:block rounded-2xl">
            <div class="grid grid-cols-8 gap-4 text-xl font-semibold text-center font-jakarta">
                <div>No</div>
                <div class="col-span-2 text-left">Judul Simulasi</div>
                <div>Buku</div>
                <div>Durasi (mnt)</div>
                <div>Jumlah Soal</div>
                <div>Status</div>
                <div>Aksi</div>
            </div>
        </div>

        <!-- List Simulasi -->
        <?php $__empty_1 = true; $__currentLoopData = $simulasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="p-4 mb-4 bg-white shadow-md rounded-xl sm:p-6 lg:p-4 lg:mb-2">
            
            <!-- Mobile View -->
            <div class="space-y-3 lg:hidden">
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">No:</span>
                    <span class="font-medium"><?php echo e($index + 1); ?></span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">Judul:</span>
                    <span class="font-medium"><?php echo e($sim->judul_simulasi); ?></span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">Buku:</span>
                    <span><?php echo e($sim->buku->judul_buku ?? '-'); ?></span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">Durasi:</span>
                    <span><?php echo e($sim->durasi_menit); ?> menit</span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">Jumlah Soal:</span>
                    <span><?php echo e($sim->jumlah_soal); ?></span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="font-medium text-gray-600">Status:</span>
                    <span>
                        <?php if($sim->status === 'aktif'): ?>
                            <span class="px-3 py-1 text-sm font-semibold text-white bg-green-500 rounded-full">Aktif</span>
                        <?php else: ?>
                            <span class="px-3 py-1 text-sm font-semibold text-white bg-gray-400 rounded-full">Nonaktif</span>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="flex flex-col gap-2 pt-4 mt-4 border-t">
                    <a href="<?php echo e(route('simulasi.edit', $sim->id_simulasi)); ?>" class="px-3 py-2 text-sm font-medium text-center text-white rounded-lg bg-admin-green hover:bg-opacity-90">Edit</a>
                    <a href="<?php echo e(route('soal-simulasi.index', $sim->id_simulasi)); ?>" class="px-3 py-2 text-sm font-medium text-center text-white bg-blue-500 rounded-lg hover:bg-opacity-90">Kelola Soal</a>
                    <form action="<?php echo e(route('simulasi.destroy', $sim->id_simulasi)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus simulasi ini?');">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="flex items-center justify-center w-full gap-2 px-3 py-2 text-sm font-medium text-white transition-colors bg-red-500 rounded-lg hover:bg-red-600">
        <!-- Ikon dipindah ke dalam button -->
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" 
             viewBox="0 0 24 24" fill="none" stroke="currentColor" 
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 6h18"/>
            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
        </svg>
        <span>Hapus</span>
    </button>
</form>

                </div>
            </div>

            <!-- Desktop View -->
            <div class="items-center hidden grid-cols-8 gap-4 text-center lg:grid font-jakarta">
                <div class="font-medium"><?php echo e($index + 1); ?></div>
                <div class="col-span-2 font-medium text-left"><?php echo e($sim->judul_simulasi); ?></div>
                <div class="font-medium"><?php echo e($sim->buku->judul_buku ?? '-'); ?></div>
                <div class="font-medium"><?php echo e($sim->durasi_menit); ?></div>
                <div class="font-medium"><?php echo e($sim->jumlah_soal); ?></div>
                
                <!-- Status Badge -->
                <div>
                    <?php if($sim->status === 'aktif'): ?>
                        <span class="px-3 py-1 text-sm font-semibold text-white bg-green-500 rounded-full">Aktif</span>
                    <?php else: ?>
                        <span class="px-3 py-1 text-sm font-semibold text-white bg-gray-400 rounded-full">Nonaktif</span>
                    <?php endif; ?>
                </div>
                
                <!-- Action -->
                <div class="flex justify-center gap-4">
                    <a href="<?php echo e(route('simulasi.edit', $sim->id_simulasi)); ?>" class="transition-opacity hover:opacity-80" title="Edit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"
                             viewBox="0 0 24 24" fill="none" stroke="currentColor"
                             stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                             class="text-admin-green fill-admin-green">
                            <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                            <path d="m15 5 4 4"/>
                        </svg>
                    </a>
                    <a href="<?php echo e(route('soal-simulasi.index', $sim->id_simulasi)); ?>" class="transition-opacity hover:opacity-80" title="Kelola Soal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-blue-500">
                            <path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/>
                            <polyline points="17 8 21 12 17 16"/>
                            <line x1="3" y1="12" x2="21" y2="12"/>
                        </svg>
                    </a>
                    <form action="<?php echo e(route('simulasi.destroy', $sim->id_simulasi)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus simulasi ini?');" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="transition-opacity hover:opacity-80" title="Hapus">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                                 viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                 class="text-admin-red fill-admin-red">
                                <path d="M3 6h18"/>
                                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="p-6 text-center bg-white shadow-md rounded-xl">
            <p class="text-lg text-gray-500">Belum ada data simulasi</p>
        </div>
        <?php endif; ?>

        <!-- Pagination -->
        <div class="mt-8">
            <?php echo e($simulasi->links()); ?>

        </div>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MyProject\resources\views/admin/simulasi/index.blade.php ENDPATH**/ ?>